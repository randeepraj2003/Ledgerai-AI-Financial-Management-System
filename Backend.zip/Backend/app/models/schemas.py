from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

# Auth schemas
class UserCreate(BaseModel):
    email: EmailStr
    full_name: str
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserOut(BaseModel):
    id: int
    email: str
    full_name: str
    role: str
    created_at: datetime
    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserOut

# Invoice schemas
class LineItem(BaseModel):
    description: str = ""
    quantity: float = 0
    unit_price: float = 0.0
    total: float = 0.0

class InvoiceOut(BaseModel):
    id: int
    file_name: str
    vendor_name: Optional[str]
    invoice_number: Optional[str]
    invoice_date: Optional[str]
    due_date: Optional[str]
    subtotal: float
    tax_amount: float
    total_amount: float
    currency: str
    status: str
    fraud_flags: List[str]
    confidence_score: float
    ai_summary: Optional[str]
    category: str
    created_at: datetime
    class Config:
        from_attributes = True

class InvoiceUpdate(BaseModel):
    status: Optional[str] = None
    category: Optional[str] = None

# Analytics schemas
class MonthlySummary(BaseModel):
    month: str
    total: float
    count: int

class AnalyticsSummary(BaseModel):
    total_spend: float
    invoice_count: int
    approved_count: int
    flagged_count: int
    pending_count: int
    avg_processing_time_hours: float
    top_vendors: List[dict]
    monthly_data: List[MonthlySummary]
    category_breakdown: List[dict]

# Chat schemas
class ChatRequest(BaseModel):
    message: str

class ChatResponse(BaseModel):
    response: str
    message_id: int
