from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database import get_db
from app.models.models import User, ChatMessage, Invoice
from app.models.schemas import ChatRequest, ChatResponse
from app.services.auth import get_current_user

router = APIRouter(tags=["ai"])

def answer_from_db(message: str, user_id: int, db: Session) -> str:
    msg = message.lower()
    invoices = db.query(Invoice).filter(Invoice.user_id == user_id).all()

    if not invoices:
        return "You have no invoices yet. Upload some PDF invoices to get started!"

    total_spend = sum(i.total_amount for i in invoices)
    approved = [i for i in invoices if i.status == "approved"]
    flagged = [i for i in invoices if i.status == "flagged"]
    pending = [i for i in invoices if i.status == "pending"]

    # Vendor totals
    vendor_totals = {}
    for inv in invoices:
        v = inv.vendor_name or "Unknown"
        vendor_totals[v] = vendor_totals.get(v, 0) + inv.total_amount
    top_vendors = sorted(vendor_totals.items(), key=lambda x: x[1], reverse=True)

    # Category totals
    cat_totals = {}
    for inv in invoices:
        c = inv.category or "Other"
        cat_totals[c] = cat_totals.get(c, 0) + inv.total_amount

    # Answer based on question
    if any(w in msg for w in ["total", "spend", "spent", "much", "amount"]):
        return f"Your total spend is ${total_spend:,.2f} across {len(invoices)} invoices."

    elif any(w in msg for w in ["vendor", "supplier", "company", "top"]):
        if top_vendors:
            lines = [f"{i+1}. {v} — ${t:,.2f}" for i, (v, t) in enumerate(top_vendors[:5])]
            return "Your top vendors by spend:\n" + "\n".join(lines)
        return "No vendor data found."

    elif any(w in msg for w in ["pending", "approve", "waiting"]):
        if pending:
            lines = [f"- {i.vendor_name or i.file_name} — ${i.total_amount:,.2f}" for i in pending[:5]]
            return f"You have {len(pending)} pending invoice(s):\n" + "\n".join(lines)
        return "No pending invoices. All invoices have been processed!"

    elif any(w in msg for w in ["flag", "fraud", "suspicious", "problem"]):
        if flagged:
            lines = [f"- {i.vendor_name or i.file_name}: {', '.join(i.fraud_flags)}" for i in flagged[:5]]
            return f"You have {len(flagged)} flagged invoice(s):\n" + "\n".join(lines)
        return "No flagged invoices. Everything looks clean!"

    elif any(w in msg for w in ["approved", "cleared", "paid"]):
        if approved:
            lines = [f"- {i.vendor_name or i.file_name} — ${i.total_amount:,.2f}" for i in approved[:5]]
            return f"You have {len(approved)} approved invoice(s):\n" + "\n".join(lines)
        return "No approved invoices yet. Go to Invoices and click Approve!"

    elif any(w in msg for w in ["category", "categor", "software", "legal", "marketing", "operations"]):
        if cat_totals:
            lines = [f"- {c}: ${t:,.2f}" for c, t in sorted(cat_totals.items(), key=lambda x: x[1], reverse=True)]
            return "Spending by category:\n" + "\n".join(lines)
        return "No category data available."

    elif any(w in msg for w in ["summary", "overview", "report"]):
        vendor_line = f"Top vendor: {top_vendors[0][0]} (${top_vendors[0][1]:,.2f})" if top_vendors else ""
        return (
            f"Finance Summary:\n"
            f"- Total invoices: {len(invoices)}\n"
            f"- Total spend: ${total_spend:,.2f}\n"
            f"- Approved: {len(approved)}\n"
            f"- Pending: {len(pending)}\n"
            f"- Flagged: {len(flagged)}\n"
            f"- {vendor_line}"
        )

    elif any(w in msg for w in ["hello", "hi", "hey", "help"]):
        return (
            "Hello! I'm your Finance Assistant. Ask me things like:\n"
            "- What is my total spend?\n"
            "- Who are my top vendors?\n"
            "- Show me pending invoices\n"
            "- Give me a summary\n"
            "- Are there any flagged invoices?"
        )

    else:
        return (
            f"You have {len(invoices)} invoices with total spend of ${total_spend:,.2f}.\n"
            f"Pending: {len(pending)} | Approved: {len(approved)} | Flagged: {len(flagged)}\n\n"
            "Try asking: 'top vendors', 'pending invoices', 'spending by category', or 'give me a summary'."
        )


@router.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    user_msg = ChatMessage(user_id=current_user.id, role="user", content=request.message)
    db.add(user_msg)
    db.commit()

    response = answer_from_db(request.message, current_user.id, db)

    ai_msg = ChatMessage(user_id=current_user.id, role="assistant", content=response)
    db.add(ai_msg)
    db.commit()
    db.refresh(ai_msg)

    return {"response": response, "message_id": ai_msg.id}


@router.get("/history")
def get_history(limit: int = 20, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    messages = db.query(ChatMessage).filter(
        ChatMessage.user_id == current_user.id
    ).order_by(ChatMessage.created_at.desc()).limit(limit).all()
    return [{"role": m.role, "content": m.content, "created_at": m.created_at} for m in reversed(messages)]