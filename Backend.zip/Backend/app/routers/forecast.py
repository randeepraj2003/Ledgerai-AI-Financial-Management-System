from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.models import User, Invoice
from app.services.auth import get_current_user
from app.services.forecasting import forecast_next_months
from app.services.anomaly_detection import detect_anomalies
from app.services.nlp_categorizer import batch_categorize
from app.services.vendor_risk import calculate_vendor_risk
from app.services.duplicate_detector import detect_duplicates
from app.services.random_forest_predictor import predict_invoice_amounts
from app.services.dbscan_clustering import analyze_spending_patterns
from app.services.arima_forecasting import arima_forecast
from app.services.health_score import calculate_health_score
from app.services.semantic_search import semantic_search

router = APIRouter(tags=["analytics"])

@router.get("/forecast")
def get_forecast(months: int = 3, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return forecast_next_months(current_user.id, db, months)

@router.get("/arima-forecast")
def get_arima_forecast(months: int = 3, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return arima_forecast(current_user.id, db, months)

@router.get("/anomalies")
def get_anomalies(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return detect_anomalies(current_user.id, db)

@router.get("/vendor-risk")
def get_vendor_risk(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return calculate_vendor_risk(current_user.id, db)

@router.get("/duplicates")
def get_duplicates(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return detect_duplicates(current_user.id, db)

@router.get("/random-forest")
def get_random_forest(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return predict_invoice_amounts(current_user.id, db)

@router.get("/spending-patterns")
def get_spending_patterns(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return analyze_spending_patterns(current_user.id, db)

@router.get("/health-score")
def get_health_score(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return calculate_health_score(current_user.id, db)

@router.get("/search")
def search_invoices(q: str = Query(..., min_length=2), db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return semantic_search(q, current_user.id, db)

@router.post("/categorize")
def categorize_invoices(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    invoices = db.query(Invoice).filter(Invoice.user_id == current_user.id).all()
    invoice_list = [{"id": i.id, "vendor_name": i.vendor_name, "category": i.category} for i in invoices]
    results = batch_categorize(invoice_list)
    for result in results:
        inv = db.query(Invoice).filter(Invoice.id == result["id"]).first()
        if inv and result["new_category"] != "Other":
            inv.category = result["new_category"]
    db.commit()
    return {"status": "success", "results": results, "updated": len(results)}