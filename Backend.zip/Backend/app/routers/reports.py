from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from io import BytesIO
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from app.database import get_db
from app.models.models import User, Invoice
from app.services.auth import get_current_user

router = APIRouter(tags=["reports"])

@router.get("/export/excel")
def export_excel(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    invoices = db.query(Invoice).filter(Invoice.user_id == current_user.id).order_by(Invoice.created_at.desc()).all()

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Invoices"

    # Header style
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")

    headers = ["ID", "Vendor", "Invoice #", "Date", "Due Date", "Subtotal", "Tax", "Total", "Currency", "Category", "Status", "Flags"]
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center")

    # Data rows
    status_colors = {"approved": "C6EFCE", "flagged": "FFEB9C", "rejected": "FFC7CE", "pending": "DDEBF7"}
    for row, inv in enumerate(invoices, 2):
        ws.cell(row=row, column=1, value=inv.id)
        ws.cell(row=row, column=2, value=inv.vendor_name or "")
        ws.cell(row=row, column=3, value=inv.invoice_number or "")
        ws.cell(row=row, column=4, value=inv.invoice_date or "")
        ws.cell(row=row, column=5, value=inv.due_date or "")
        ws.cell(row=row, column=6, value=inv.subtotal)
        ws.cell(row=row, column=7, value=inv.tax_amount)
        ws.cell(row=row, column=8, value=inv.total_amount)
        ws.cell(row=row, column=9, value=inv.currency)
        ws.cell(row=row, column=10, value=inv.category)
        status_cell = ws.cell(row=row, column=11, value=inv.status)
        color = status_colors.get(inv.status, "FFFFFF")
        status_cell.fill = PatternFill(start_color=color, end_color=color, fill_type="solid")
        ws.cell(row=row, column=12, value=", ".join(inv.fraud_flags) if inv.fraud_flags else "None")

    # Auto column width
    for col in ws.columns:
        max_len = max(len(str(cell.value or "")) for cell in col)
        ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 40)

    # Summary sheet
    ws2 = wb.create_sheet("Summary")
    ws2["A1"] = "Finance Dashboard Export"
    ws2["A1"].font = Font(bold=True, size=14)
    ws2["A3"] = "Total Invoices"
    ws2["B3"] = len(invoices)
    ws2["A4"] = "Total Spend"
    ws2["B4"] = round(sum(i.total_amount for i in invoices), 2)
    ws2["A5"] = "Flagged Invoices"
    ws2["B5"] = sum(1 for i in invoices if i.status == "flagged")
    ws2["A6"] = "Approved Invoices"
    ws2["B6"] = sum(1 for i in invoices if i.status == "approved")

    output = BytesIO()
    wb.save(output)
    output.seek(0)

    return StreamingResponse(
        output,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=finance_report.xlsx"}
    )
