import os
import shutil
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models.models import User, Invoice
from app.models.schemas import InvoiceOut, InvoiceUpdate
from app.services.auth import get_current_user
from app.services.invoice_ai import extract_invoice_data, detect_fraud, generate_invoice_summary
from app.config import settings

router = APIRouter(tags=["invoices"])

os.makedirs(settings.UPLOAD_DIR, exist_ok=True)

def process_invoice_background(invoice_id: int, file_path: str, db: Session):
    """Run AI extraction in the background after upload."""
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not invoice:
        return

    # Extract data using Claude
    data = extract_invoice_data(file_path)

    # Get existing invoices for duplicate check
    existing = db.query(Invoice).filter(
        Invoice.user_id == invoice.user_id,
        Invoice.id != invoice_id
    ).all()
    existing_list = [{"total_amount": i.total_amount, "vendor_name": i.vendor_name, "invoice_number": i.invoice_number} for i in existing]

    fraud_result = detect_fraud(data, existing_list)
    summary = generate_invoice_summary(data)

    invoice.vendor_name = data.get("vendor_name")
    invoice.invoice_number = data.get("invoice_number")
    invoice.invoice_date = data.get("invoice_date")
    invoice.due_date = data.get("due_date")
    invoice.subtotal = data.get("subtotal", 0.0) or 0.0
    invoice.tax_amount = data.get("tax_amount", 0.0) or 0.0
    invoice.total_amount = data.get("total_amount", 0.0) or 0.0
    invoice.currency = data.get("currency", "USD") or "USD"
    invoice.bank_account = data.get("bank_account")
    invoice.category = data.get("category", "Other") or "Other"
    invoice.line_items = data.get("line_items", [])
    invoice.confidence_score = data.get("confidence_score", 0.0) or 0.0
    invoice.fraud_flags = fraud_result["flags"]
    invoice.ai_summary = summary
    invoice.status = "flagged" if fraud_result["is_flagged"] else "pending"

    db.commit()

@router.post("/upload", response_model=InvoiceOut)
async def upload_invoice(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are accepted")

    file_path = os.path.join(settings.UPLOAD_DIR, f"{current_user.id}_{file.filename}")
    with open(file_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    invoice = Invoice(
        user_id=current_user.id,
        file_name=file.filename,
        file_path=file_path,
        status="pending"
    )
    db.add(invoice)
    db.commit()
    db.refresh(invoice)

    # Run AI processing in background so upload returns fast
    background_tasks.add_task(process_invoice_background, invoice.id, file_path, db)

    return invoice

@router.get("/", response_model=List[InvoiceOut])
def list_invoices(
    status: str = None,
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = db.query(Invoice).filter(Invoice.user_id == current_user.id)
    if status:
        query = query.filter(Invoice.status == status)
    return query.order_by(Invoice.created_at.desc()).offset(skip).limit(limit).all()

@router.get("/{invoice_id}", response_model=InvoiceOut)
def get_invoice(invoice_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id, Invoice.user_id == current_user.id).first()
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return invoice

@router.patch("/{invoice_id}", response_model=InvoiceOut)
def update_invoice(
    invoice_id: int,
    update: InvoiceUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id, Invoice.user_id == current_user.id).first()
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    if update.status:
        invoice.status = update.status
    if update.category:
        invoice.category = update.category
    db.commit()
    db.refresh(invoice)
    return invoice

@router.delete("/{invoice_id}")
def delete_invoice(invoice_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id, Invoice.user_id == current_user.id).first()
    if not invoice:
        raise HTTPException(status_code=404, detail="Invoice not found")
    if os.path.exists(invoice.file_path):
        os.remove(invoice.file_path)
    db.delete(invoice)
    db.commit()
    return {"message": "Invoice deleted"}
