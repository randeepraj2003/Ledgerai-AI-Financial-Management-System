from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func, extract
from datetime import datetime
from app.database import get_db
from app.models.models import User, Invoice
from app.models.schemas import AnalyticsSummary
from app.services.auth import get_current_user

router = APIRouter(tags=["analytics"])

@router.get("/summary", response_model=AnalyticsSummary)
def get_summary(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    invoices = db.query(Invoice).filter(Invoice.user_id == current_user.id).all()

    total_spend = sum(i.total_amount for i in invoices)
    approved = [i for i in invoices if i.status == "approved"]
    flagged = [i for i in invoices if i.status == "flagged"]
    pending = [i for i in invoices if i.status == "pending"]

    # Monthly data for chart
    monthly_raw = db.query(
        extract("year", Invoice.created_at).label("year"),
        extract("month", Invoice.created_at).label("month"),
        func.sum(Invoice.total_amount).label("total"),
        func.count(Invoice.id).label("count")
    ).filter(Invoice.user_id == current_user.id).group_by("year", "month").order_by("year", "month").all()

    month_names = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    monthly_data = [
        {"month": f"{month_names[int(r.month)-1]} {int(r.year)}", "total": round(r.total, 2), "count": r.count}
        for r in monthly_raw
    ]

    # Top vendors
    vendor_totals = {}
    for inv in invoices:
        v = inv.vendor_name or "Unknown"
        vendor_totals[v] = vendor_totals.get(v, 0) + inv.total_amount
    top_vendors = [{"name": k, "total": round(v, 2)} for k, v in sorted(vendor_totals.items(), key=lambda x: x[1], reverse=True)[:5]]

    # Category breakdown
    cat_totals = {}
    for inv in invoices:
        c = inv.category or "Other"
        cat_totals[c] = cat_totals.get(c, 0) + inv.total_amount
    category_breakdown = [{"category": k, "total": round(v, 2)} for k, v in sorted(cat_totals.items(), key=lambda x: x[1], reverse=True)]

    return {
        "total_spend": round(total_spend, 2),
        "invoice_count": len(invoices),
        "approved_count": len(approved),
        "flagged_count": len(flagged),
        "pending_count": len(pending),
        "avg_processing_time_hours": 0.5,
        "top_vendors": top_vendors,
        "monthly_data": monthly_data,
        "category_breakdown": category_breakdown
    }
