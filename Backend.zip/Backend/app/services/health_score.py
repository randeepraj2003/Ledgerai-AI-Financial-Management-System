import numpy as np
from sqlalchemy.orm import Session
from app.models.models import Invoice
from datetime import datetime, timedelta

def calculate_health_score(user_id: int, db: Session) -> dict:
    """
    Calculate a 0-100 Financial Health Score based on:
    - Approval rate (25 points)
    - Fraud/flag rate (25 points)
    - Spending consistency (20 points)
    - Payment timeliness (15 points)
    - Vendor diversity (15 points)
    """
    invoices = db.query(Invoice).filter(
        Invoice.user_id == user_id
    ).all()

    if not invoices:
        return {
            "status": "no_data",
            "message": "No invoices found.",
            "score": 0,
            "grade": "N/A"
        }

    total = len(invoices)
    approved = sum(1 for i in invoices if i.status == "approved")
    flagged = sum(1 for i in invoices if i.status == "flagged")
    rejected = sum(1 for i in invoices if i.status == "rejected")
    pending = sum(1 for i in invoices if i.status == "pending")
    amounts = [i.total_amount for i in invoices if i.total_amount > 0]

    # Component 1 — Approval Rate (25 points)
    approval_rate = approved / total if total > 0 else 0
    approval_score = approval_rate * 25

    # Component 2 — Fraud/Flag Rate (25 points)
    flag_rate = (flagged + rejected) / total if total > 0 else 0
    fraud_score = (1 - flag_rate) * 25

    # Component 3 — Spending Consistency (20 points)
    consistency_score = 20
    if len(amounts) > 1:
        cv = np.std(amounts) / np.mean(amounts) if np.mean(amounts) > 0 else 1
        consistency_score = max(0, 20 - (cv * 10))

    # Component 4 — Processing Efficiency (15 points)
    processed = approved + rejected
    processing_rate = processed / total if total > 0 else 0
    processing_score = processing_rate * 15

    # Component 5 — Vendor Diversity (15 points)
    unique_vendors = len(set(i.vendor_name for i in invoices if i.vendor_name))
    diversity_ratio = min(unique_vendors / max(total, 1), 1.0)
    diversity_score = diversity_ratio * 15

    # Total score
    total_score = round(
        approval_score + fraud_score + consistency_score +
        processing_score + diversity_score
    )
    total_score = max(0, min(100, total_score))

    # Grade
    if total_score >= 80:
        grade = "A"
        grade_label = "Excellent"
        grade_color = "green"
    elif total_score >= 65:
        grade = "B"
        grade_label = "Good"
        grade_color = "accent"
    elif total_score >= 50:
        grade = "C"
        grade_label = "Average"
        grade_color = "amber"
    elif total_score >= 35:
        grade = "D"
        grade_label = "Below Average"
        grade_color = "red"
    else:
        grade = "F"
        grade_label = "Poor"
        grade_color = "red"

    # Generate insights
    insights = []
    if approval_rate < 0.5:
        insights.append("Low approval rate — review pending invoices to improve score")
    else:
        insights.append(f"Good approval rate of {approval_rate:.0%}")

    if flag_rate > 0.2:
        insights.append(f"High fraud/flag rate of {flag_rate:.0%} — investigate flagged invoices")
    else:
        insights.append("Low fraud rate — financial controls are working well")

    if unique_vendors < 3:
        insights.append("Low vendor diversity — consider diversifying suppliers")
    else:
        insights.append(f"Good vendor diversity with {unique_vendors} unique vendors")

    if pending > total * 0.5:
        insights.append(f"{pending} invoices pending — process them to improve efficiency score")

    # Components breakdown
    components = [
        {
            "name": "Approval Rate",
            "score": round(approval_score, 1),
            "max": 25,
            "pct": round(approval_score / 25 * 100),
            "detail": f"{approved}/{total} invoices approved"
        },
        {
            "name": "Fraud Control",
            "score": round(fraud_score, 1),
            "max": 25,
            "pct": round(fraud_score / 25 * 100),
            "detail": f"{flagged + rejected} flagged/rejected invoices"
        },
        {
            "name": "Spending Consistency",
            "score": round(consistency_score, 1),
            "max": 20,
            "pct": round(consistency_score / 20 * 100),
            "detail": f"Coefficient of variation: {round(np.std(amounts)/np.mean(amounts)*100 if amounts and np.mean(amounts) > 0 else 0, 1)}%"
        },
        {
            "name": "Processing Efficiency",
            "score": round(processing_score, 1),
            "max": 15,
            "pct": round(processing_score / 15 * 100),
            "detail": f"{processed}/{total} invoices processed"
        },
        {
            "name": "Vendor Diversity",
            "score": round(diversity_score, 1),
            "max": 15,
            "pct": round(diversity_score / 15 * 100),
            "detail": f"{unique_vendors} unique vendors"
        }
    ]

    return {
        "status": "success",
        "score": total_score,
        "grade": grade,
        "grade_label": grade_label,
        "grade_color": grade_color,
        "components": components,
        "insights": insights,
        "stats": {
            "total": total,
            "approved": approved,
            "flagged": flagged,
            "rejected": rejected,
            "pending": pending,
            "unique_vendors": unique_vendors,
            "total_spend": round(sum(amounts), 2)
        }
    }