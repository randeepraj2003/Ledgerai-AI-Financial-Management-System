import numpy as np
import pandas as pd
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
from sqlalchemy.orm import Session
from app.models.models import Invoice

def analyze_spending_patterns(user_id: int, db: Session) -> dict:
    """
    DBSCAN clustering to discover hidden spending patterns
    and identify outlier transactions automatically.
    """
    invoices = db.query(Invoice).filter(
        Invoice.user_id == user_id,
        Invoice.total_amount > 0
    ).all()

    if len(invoices) < 3:
        return {
            "status": "insufficient_data",
            "message": f"Need at least 3 invoices for DBSCAN. You have {len(invoices)}.",
            "clusters": [],
            "outliers": []
        }

    # Build feature matrix
    data = []
    for inv in invoices:
        data.append({
            "id": inv.id,
            "vendor": inv.vendor_name or "Unknown",
            "category": inv.category or "Other",
            "total_amount": inv.total_amount,
            "tax_amount": inv.tax_amount or 0,
            "month": inv.created_at.month if inv.created_at else 1,
            "status": inv.status or "pending"
        })

    df = pd.DataFrame(data)

    # Features for clustering
    X = df[["total_amount", "tax_amount", "month"]].values

    # Normalize
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # DBSCAN - eps controls neighborhood size, min_samples controls cluster density
    dbscan = DBSCAN(eps=0.8, min_samples=2)
    labels = dbscan.fit_predict(X_scaled)

    df["cluster"] = labels

    # -1 means outlier in DBSCAN
    outliers = df[df["cluster"] == -1]
    clustered = df[df["cluster"] >= 0]

    # Build cluster summaries
    cluster_summaries = []
    unique_clusters = [c for c in df["cluster"].unique() if c >= 0]

    for cluster_id in sorted(unique_clusters):
        cluster_data = df[df["cluster"] == cluster_id]
        amounts = cluster_data["total_amount"].values
        categories = cluster_data["category"].value_counts()

        cluster_summaries.append({
            "cluster_id": int(cluster_id),
            "size": len(cluster_data),
            "avg_amount": round(float(np.mean(amounts)), 2),
            "min_amount": round(float(np.min(amounts)), 2),
            "max_amount": round(float(np.max(amounts)), 2),
            "total_spend": round(float(np.sum(amounts)), 2),
            "dominant_category": categories.index[0] if len(categories) > 0 else "Unknown",
            "invoices": [
                {
                    "id": int(row["id"]),
                    "vendor": row["vendor"],
                    "amount": float(row["total_amount"]),
                    "category": row["category"]
                }
                for _, row in cluster_data.iterrows()
            ]
        })

    # Outlier details
    outlier_list = [
        {
            "id": int(row["id"]),
            "vendor": row["vendor"],
            "amount": float(row["total_amount"]),
            "category": row["category"],
            "reason": "Transaction pattern differs significantly from all other invoices"
        }
        for _, row in outliers.iterrows()
    ]

    # Pattern insights
    insights = []
    if len(cluster_summaries) > 1:
        largest = max(cluster_summaries, key=lambda x: x["size"])
        insights.append(f"Largest spending cluster has {largest['size']} invoices averaging ${largest['avg_amount']:,.2f}")

    if len(outlier_list) > 0:
        insights.append(f"{len(outlier_list)} transaction(s) don't fit any pattern — review recommended")

    if len(cluster_summaries) == 0:
        insights.append("All transactions are unique — need more data for pattern discovery")

    return {
        "status": "success",
        "clusters": cluster_summaries,
        "outliers": outlier_list,
        "total_invoices": len(invoices),
        "clustered_count": len(clustered),
        "outlier_count": len(outliers),
        "n_clusters": len(unique_clusters),
        "insights": insights,
        "model": "DBSCAN Density-Based Clustering",
        "parameters": {"eps": 0.8, "min_samples": 2}
    }