import anthropic
import json
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.models.models import Invoice, User
from app.config import settings

client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)

SYSTEM_PROMPT = """You are FinanceAI, an intelligent assistant built into a finance dashboard.
You have access to the company's invoice and payment data through tools.
Be concise, use specific numbers, and always cite data when you have it.
Format currency with 2 decimal places. When asked about trends, use the data tools first."""

TOOLS = [
    {
        "name": "get_financial_summary",
        "description": "Get total spend, invoice counts by status, and top vendors from the database",
        "input_schema": {
            "type": "object",
            "properties": {
                "period": {
                    "type": "string",
                    "enum": ["all_time", "this_month", "last_month", "this_year"],
                    "description": "Time period to query"
                }
            },
            "required": ["period"]
        }
    },
    {
        "name": "get_invoices_by_status",
        "description": "Get list of invoices filtered by status",
        "input_schema": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "enum": ["pending", "approved", "flagged", "rejected"],
                    "description": "Invoice status to filter by"
                }
            },
            "required": ["status"]
        }
    }
]

def _get_financial_summary(db: Session, user_id: int, period: str) -> dict:
    query = db.query(Invoice).filter(Invoice.user_id == user_id)

    if period == "this_month":
        from datetime import datetime
        now = datetime.utcnow()
        query = query.filter(
            func.extract("month", Invoice.created_at) == now.month,
            func.extract("year", Invoice.created_at) == now.year
        )
    elif period == "last_month":
        from datetime import datetime
        from dateutil.relativedelta import relativedelta
        last = datetime.utcnow() - relativedelta(months=1)
        query = query.filter(
            func.extract("month", Invoice.created_at) == last.month,
            func.extract("year", Invoice.created_at) == last.year
        )
    elif period == "this_year":
        from datetime import datetime
        query = query.filter(
            func.extract("year", Invoice.created_at) == datetime.utcnow().year
        )

    invoices = query.all()
    total_spend = sum(i.total_amount for i in invoices)
    status_counts = {}
    vendor_totals = {}

    for inv in invoices:
        status_counts[inv.status] = status_counts.get(inv.status, 0) + 1
        vendor = inv.vendor_name or "Unknown"
        vendor_totals[vendor] = vendor_totals.get(vendor, 0) + inv.total_amount

    top_vendors = sorted(vendor_totals.items(), key=lambda x: x[1], reverse=True)[:5]

    return {
        "period": period,
        "total_spend": round(total_spend, 2),
        "invoice_count": len(invoices),
        "status_breakdown": status_counts,
        "top_vendors": [{"name": v, "total": round(t, 2)} for v, t in top_vendors]
    }

def _get_invoices_by_status(db: Session, user_id: int, status: str) -> list:
    invoices = db.query(Invoice).filter(
        Invoice.user_id == user_id,
        Invoice.status == status
    ).order_by(Invoice.created_at.desc()).limit(10).all()

    return [
        {
            "vendor": inv.vendor_name,
            "amount": inv.total_amount,
            "currency": inv.currency,
            "date": inv.invoice_date,
            "flags": inv.fraud_flags
        }
        for inv in invoices
    ]

def chat_with_finance_ai(message: str, user_id: int, db: Session) -> str:
    """Multi-turn AI chat with tool use for live DB queries."""
    messages = [{"role": "user", "content": message}]

    # First call — may request tool use
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1000,
        system=SYSTEM_PROMPT,
        tools=TOOLS,
        messages=messages
    )

    # Handle tool calls
    while response.stop_reason == "tool_use":
        tool_results = []
        for block in response.content:
            if block.type == "tool_use":
                if block.name == "get_financial_summary":
                    result = _get_financial_summary(db, user_id, block.input.get("period", "all_time"))
                elif block.name == "get_invoices_by_status":
                    result = _get_invoices_by_status(db, user_id, block.input.get("status", "pending"))
                else:
                    result = {"error": "Unknown tool"}

                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": json.dumps(result)
                })

        messages.append({"role": "assistant", "content": response.content})
        messages.append({"role": "user", "content": tool_results})

        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=1000,
            system=SYSTEM_PROMPT,
            tools=TOOLS,
            messages=messages
        )

    text_blocks = [b.text for b in response.content if hasattr(b, "text")]
    return " ".join(text_blocks) if text_blocks else "I could not generate a response."
