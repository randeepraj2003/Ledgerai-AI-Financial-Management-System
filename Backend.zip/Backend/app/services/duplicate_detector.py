import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sqlalchemy.orm import Session
from app.models.models import Invoice

def detect_duplicates(user_id: int, db: Session, threshold: float = 0.85) -> dict:
    """
    Detect near-duplicate invoices using Cosine Similarity on TF-IDF vectors.
    Catches fraud even when amounts are slightly different.
    """
    invoices = db.query(Invoice).filter(
        Invoice.user_id == user_id,
        Invoice.total_amount > 0
    ).all()

    if len(invoices) < 2:
        return {
            "status": "insufficient_data",
            "message": "Need at least 2 invoices to detect duplicates.",
            "duplicates": [],
            "clean": []
        }

    # Build text representation of each invoice
    invoice_texts = []
    invoice_info = []

    for inv in invoices:
        # Combine key fields into searchable text
        text = f"{inv.vendor_name or ''} {inv.invoice_number or ''} {inv.category or ''} {str(int(inv.total_amount or 0))}"
        text = text.lower().strip()
        invoice_texts.append(text)
        invoice_info.append({
            "id": inv.id,
            "vendor": inv.vendor_name or "Unknown",
            "invoice_number": inv.invoice_number or "N/A",
            "amount": inv.total_amount,
            "date": inv.invoice_date or "N/A",
            "status": inv.status,
            "file_name": inv.file_name,
            "text": text
        })

    # TF-IDF vectorization
    vectorizer = TfidfVectorizer(ngram_range=(1, 2))
    try:
        tfidf_matrix = vectorizer.fit_transform(invoice_texts)
    except Exception:
        return {
            "status": "error",
            "message": "Could not vectorize invoice data.",
            "duplicates": [],
            "clean": []
        }

    # Calculate cosine similarity between all pairs
    similarity_matrix = cosine_similarity(tfidf_matrix)

    # Find duplicate pairs above threshold
    duplicate_groups = []
    flagged_ids = set()
    n = len(invoices)

    for i in range(n):
        for j in range(i + 1, n):
            sim_score = float(similarity_matrix[i][j])

            # Exact amount match = very suspicious
            amount_match = abs(invoice_info[i]["amount"] - invoice_info[j]["amount"]) < 0.01
            # Same vendor = more suspicious
            vendor_match = invoice_info[i]["vendor"].lower() == invoice_info[j]["vendor"].lower()

            # Dynamic threshold — lower if amount and vendor both match
            effective_threshold = threshold
            if amount_match and vendor_match:
                effective_threshold = 0.5

            if sim_score >= effective_threshold:
                flagged_ids.add(i)
                flagged_ids.add(j)
                duplicate_groups.append({
                    "invoice_1": {
                        "id": invoice_info[i]["id"],
                        "vendor": invoice_info[i]["vendor"],
                        "amount": invoice_info[i]["amount"],
                        "invoice_number": invoice_info[i]["invoice_number"],
                        "date": invoice_info[i]["date"],
                        "file_name": invoice_info[i]["file_name"]
                    },
                    "invoice_2": {
                        "id": invoice_info[j]["id"],
                        "vendor": invoice_info[j]["vendor"],
                        "amount": invoice_info[j]["amount"],
                        "invoice_number": invoice_info[j]["invoice_number"],
                        "date": invoice_info[j]["date"],
                        "file_name": invoice_info[j]["file_name"]
                    },
                    "similarity_score": round(sim_score * 100, 1),
                    "amount_match": amount_match,
                    "vendor_match": vendor_match,
                    "risk": "HIGH" if (amount_match and vendor_match) else "MEDIUM"
                })

    # Clean invoices (not flagged)
    clean_invoices = [
        {
            "id": invoice_info[i]["id"],
            "vendor": invoice_info[i]["vendor"],
            "amount": invoice_info[i]["amount"],
            "invoice_number": invoice_info[i]["invoice_number"]
        }
        for i in range(n) if i not in flagged_ids
    ]

    return {
        "status": "success",
        "duplicate_pairs": duplicate_groups,
        "clean_invoices": clean_invoices,
        "total_invoices": n,
        "duplicates_found": len(duplicate_groups),
        "clean_count": len(clean_invoices),
        "model": "TF-IDF Cosine Similarity",
        "threshold_used": threshold,
        "message": f"Found {len(duplicate_groups)} potential duplicate pair(s) out of {n} invoices"
    }