import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sqlalchemy.orm import Session
from app.models.models import Invoice
import re

def semantic_search(query: str, user_id: int, db: Session, top_k: int = 5) -> dict:
    """
    Search invoices using natural language — TF-IDF semantic similarity.
    Example queries:
    - 'software invoices above 5000'
    - 'legal services last month'
    - 'flagged invoices from techsoft'
    """
    if not query or len(query.strip()) < 2:
        return {"status": "error", "message": "Query too short", "results": []}

    invoices = db.query(Invoice).filter(
        Invoice.user_id == user_id
    ).all()

    if not invoices:
        return {"status": "no_data", "message": "No invoices found", "results": []}

    # Build searchable text for each invoice
    invoice_texts = []
    invoice_data = []

    for inv in invoices:
        text = " ".join(filter(None, [
            inv.vendor_name or "",
            inv.category or "",
            inv.status or "",
            inv.invoice_number or "",
            inv.invoice_date or "",
            str(int(inv.total_amount or 0)),
            "flagged" if inv.fraud_flags and len(inv.fraud_flags) > 0 else "",
            "approved" if inv.status == "approved" else "",
            "pending" if inv.status == "pending" else "",
            inv.ai_summary or ""
        ])).lower()

        invoice_texts.append(text)
        invoice_data.append({
            "id": inv.id,
            "vendor": inv.vendor_name or "Unknown",
            "category": inv.category or "Other",
            "amount": inv.total_amount or 0,
            "status": inv.status or "pending",
            "invoice_number": inv.invoice_number or "N/A",
            "date": inv.invoice_date or "N/A",
            "file_name": inv.file_name,
            "fraud_flags": inv.fraud_flags or [],
            "text": text
        })

    # Parse query for amount filters
    amount_min = None
    amount_max = None

    above_match = re.search(r'above\s+\$?([\d,]+)', query.lower())
    below_match = re.search(r'below\s+\$?([\d,]+)', query.lower())
    over_match = re.search(r'over\s+\$?([\d,]+)', query.lower())
    under_match = re.search(r'under\s+\$?([\d,]+)', query.lower())

    if above_match:
        amount_min = float(above_match.group(1).replace(',', ''))
    if over_match:
        amount_min = float(over_match.group(1).replace(',', ''))
    if below_match:
        amount_max = float(below_match.group(1).replace(',', ''))
    if under_match:
        amount_max = float(under_match.group(1).replace(',', ''))

    # Clean query for TF-IDF
    clean_query = re.sub(r'(above|below|over|under)\s+\$?[\d,]+', '', query.lower()).strip()
    clean_query = re.sub(r'\b(show|me|all|find|get|list|invoices?|the)\b', '', clean_query).strip()

    # TF-IDF search
    all_texts = invoice_texts + [clean_query]
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), min_df=1)

    try:
        tfidf_matrix = vectorizer.fit_transform(all_texts)
        query_vector = tfidf_matrix[-1]
        doc_vectors = tfidf_matrix[:-1]
        similarities = cosine_similarity(query_vector, doc_vectors)[0]
    except Exception:
        similarities = np.zeros(len(invoice_texts))

    # Apply amount filters + combine with similarity
    results = []
    for i, inv in enumerate(invoice_data):
        sim_score = float(similarities[i])

        # Apply amount filters
        if amount_min and inv["amount"] < amount_min:
            continue
        if amount_max and inv["amount"] > amount_max:
            continue

        # Boost score for keyword matches
        query_lower = query.lower()
        boost = 0
        if inv["vendor"].lower() in query_lower:
            boost += 0.4
        if inv["category"].lower() in query_lower:
            boost += 0.3
        if inv["status"].lower() in query_lower:
            boost += 0.3

        final_score = min(sim_score + boost, 1.0)
        results.append({**inv, "similarity": round(final_score * 100, 1)})

    # Sort by similarity
    results = sorted(results, key=lambda x: x["similarity"], reverse=True)

    # Return top_k results with similarity > 0
    top_results = [r for r in results[:top_k] if r["similarity"] > 0]

    # If no results, return all (amount filter might have matched)
    if not top_results and results:
        top_results = results[:top_k]

    return {
        "status": "success",
        "query": query,
        "results": top_results,
        "total_found": len(top_results),
        "total_invoices": len(invoices),
        "filters_applied": {
            "amount_min": amount_min,
            "amount_max": amount_max
        }
    }