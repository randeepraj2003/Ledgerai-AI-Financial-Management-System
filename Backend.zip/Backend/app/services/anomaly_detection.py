import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sqlalchemy.orm import Session
from app.models.models import Invoice

def detect_anomalies(user_id: int, db: Session) -> dict:
    """
    Use Isolation Forest (unsupervised ML) to detect
    anomalous invoices based on amount, timing and vendor patterns.
    """
    invoices = db.query(Invoice).filter(
        Invoice.user_id == user_id,
        Invoice.total_amount > 0
    ).all()

    if len(invoices) < 3:
        return {
            "status": "insufficient_data",
            "message": f"Need at least 3 invoices for anomaly detection. You have {len(invoices)}.",
            "anomalies": [],
            "normal": [],
            "stats": {}
        }

    # Build feature matrix
    data = []
    for inv in invoices:
        data.append({
            "id": inv.id,
            "vendor": inv.vendor_name or "Unknown",
            "amount": inv.total_amount,
            "tax": inv.tax_amount or 0,
            "subtotal": inv.subtotal or 0,
            "file_name": inv.file_name,
            "status": inv.status,
            "category": inv.category or "Other"
        })

    df = pd.DataFrame(data)

    # Feature engineering
    df["tax_ratio"] = df["tax"] / df["amount"].replace(0, 1)
    df["amount_log"] = np.log1p(df["amount"])

    # Vendor frequency encoding
    vendor_counts = df["vendor"].value_counts().to_dict()
    df["vendor_freq"] = df["vendor"].map(vendor_counts)

    # Features for Isolation Forest
    features = ["amount_log", "tax_ratio", "vendor_freq"]
    X = df[features].fillna(0)

    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Train Isolation Forest
    # contamination = expected % of anomalies (10%)
    model = IsolationForest(
        n_estimators=100,
        contamination=0.1,
        random_state=42
    )
    predictions = model.fit_predict(X_scaled)
    scores = model.score_samples(X_scaled)

    # Add results to dataframe
    df["anomaly"] = predictions  # -1 = anomaly, 1 = normal
    df["anomaly_score"] = scores  # lower = more anomalous

    # Normalize score to 0-100 (higher = more suspicious)
    min_score = scores.min()
    max_score = scores.max()
    if max_score != min_score:
        df["risk_score"] = ((max_score - scores) / (max_score - min_score) * 100).round(1)
    else:
        df["risk_score"] = 50.0

    # Split anomalies and normal
    anomalies = df[df["anomaly"] == -1].sort_values("risk_score", ascending=False)
    normal = df[df["anomaly"] == 1].sort_values("risk_score", ascending=False)

    # Generate reason for each anomaly
    avg_amount = df["amount"].mean()
    std_amount = df["amount"].std()

    def get_reason(row):
        reasons = []
        if row["amount"] > avg_amount + 2 * std_amount:
            reasons.append(f"Amount ${row['amount']:,.2f} is unusually high")
        elif row["amount"] < avg_amount - 1.5 * std_amount:
            reasons.append(f"Amount ${row['amount']:,.2f} is unusually low")
        if row["tax_ratio"] > 0.25:
            reasons.append(f"High tax ratio ({row['tax_ratio']:.1%})")
        if row["tax_ratio"] == 0:
            reasons.append("No tax amount detected")
        if row["vendor_freq"] == 1:
            reasons.append("First invoice from this vendor")
        if not reasons:
            reasons.append("Statistical pattern differs from other invoices")
        return " | ".join(reasons)

    # Build response
    anomaly_list = []
    for _, row in anomalies.iterrows():
        anomaly_list.append({
            "id": int(row["id"]),
            "vendor": row["vendor"],
            "amount": float(row["amount"]),
            "risk_score": float(row["risk_score"]),
            "reason": get_reason(row),
            "category": row["category"],
            "file_name": row["file_name"]
        })

    normal_list = []
    for _, row in normal.iterrows():
        normal_list.append({
            "id": int(row["id"]),
            "vendor": row["vendor"],
            "amount": float(row["amount"]),
            "risk_score": float(row["risk_score"]),
            "category": row["category"],
            "file_name": row["file_name"]
        })

    # Stats
    stats = {
        "total_invoices": len(invoices),
        "anomalies_found": len(anomalies),
        "normal_invoices": len(normal),
        "avg_amount": round(float(avg_amount), 2),
        "std_amount": round(float(std_amount), 2),
        "highest_risk_vendor": anomaly_list[0]["vendor"] if anomaly_list else None,
        "model": "Isolation Forest",
        "features_used": features
    }

    return {
        "status": "success",
        "anomalies": anomaly_list,
        "normal": normal_list,
        "stats": stats,
        "message": f"Found {len(anomalies)} anomalous invoice(s) out of {len(invoices)} total"
    }