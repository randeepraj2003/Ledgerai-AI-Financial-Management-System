import fitz
import re
from app.config import settings

def extract_invoice_data(pdf_path: str) -> dict:
    try:
        doc = fitz.open(pdf_path)
        text = ""
        for page in doc:
            text += page.get_text()
        doc.close()
    except Exception as e:
        return _empty_invoice(str(e))

    data = {
        "vendor_name": None, "invoice_number": None,
        "invoice_date": None, "due_date": None,
        "subtotal": 0.0, "tax_amount": 0.0, "total_amount": 0.0,
        "currency": "USD", "bank_account": None,
        "category": "Other", "line_items": [],
        "confidence_score": 0.7
    }

    lines = [l.strip() for l in text.split('\n') if l.strip()]
    full_text = text.lower()

    # --- Vendor name ---
    for line in lines:
        low = line.lower()
        if any(w in low for w in ['ltd','inc','llc','solutions','consulting',
               'services','digital','legal','cloud','supply','pro','direct',
               'infrastructure','consultants','marketing']):
            if len(line) > 3 and len(line) < 60:
                data["vendor_name"] = line.strip()
                break

    # --- Invoice number ---
    for line in lines:
        m = re.search(r'(INV[-\s]?\d{4}[-\s]?\d{3,})', line, re.I)
        if m:
            data["invoice_number"] = m.group(1)
            break

    # --- Dates ---
    all_dates = re.findall(r'\d{4}-\d{2}-\d{2}', text)
    if len(all_dates) >= 1:
        data["invoice_date"] = all_dates[0]
    if len(all_dates) >= 2:
        data["due_date"] = all_dates[1]

    # --- Amounts: find all dollar amounts in text ---
    all_amounts = re.findall(r'\$?([\d,]+\.\d{2})', text)
    all_amounts = [float(a.replace(',', '')) for a in all_amounts if float(a.replace(',', '')) > 0]

    # Find subtotal, tax, total from labeled lines
    for i, line in enumerate(lines):
        low = line.lower()

        # Total due / grand total (highest priority)
        if 'total due' in low or 'total:' in low or 'amount due' in low or 'grand total' in low:
            m = re.search(r'\$?([\d,]+\.\d{2})', line)
            if not m and i + 1 < len(lines):
                m = re.search(r'\$?([\d,]+\.\d{2})', lines[i+1])
            if m:
                data["total_amount"] = float(m.group(1).replace(',', ''))

        # Subtotal
        elif 'subtotal' in low:
            m = re.search(r'\$?([\d,]+\.\d{2})', line)
            if not m and i + 1 < len(lines):
                m = re.search(r'\$?([\d,]+\.\d{2})', lines[i+1])
            if m:
                data["subtotal"] = float(m.group(1).replace(',', ''))

        # Tax
        elif re.search(r'tax\s*\(?\d*%?\)?', low) and 'total' not in low:
            m = re.search(r'\$?([\d,]+\.\d{2})', line)
            if not m and i + 1 < len(lines):
                m = re.search(r'\$?([\d,]+\.\d{2})', lines[i+1])
            if m:
                data["tax_amount"] = float(m.group(1).replace(',', ''))

    # If total still 0, calculate from subtotal + tax
    if data["total_amount"] == 0 and data["subtotal"] > 0:
        data["total_amount"] = round(data["subtotal"] + data["tax_amount"], 2)

    # If still 0, pick the largest amount found in the document
    if data["total_amount"] == 0 and all_amounts:
        data["total_amount"] = max(all_amounts)

    # If subtotal still 0, estimate it
    if data["subtotal"] == 0 and data["total_amount"] > 0 and data["tax_amount"] > 0:
        data["subtotal"] = round(data["total_amount"] - data["tax_amount"], 2)
    elif data["subtotal"] == 0 and data["total_amount"] > 0:
        data["subtotal"] = round(data["total_amount"] / 1.18, 2)
        data["tax_amount"] = round(data["total_amount"] - data["subtotal"], 2)

    # --- Bank account ---
    for line in lines:
        low = line.lower()
        if 'account' in low or 'bank' in low:
            m = re.search(r'\d{8,14}', line)
            if m:
                data["bank_account"] = m.group(0)
                break

    # --- Category from vendor name ---
    if data["vendor_name"]:
        name = data["vendor_name"].lower()
        if any(w in name for w in ['tech','software','cloud','digital','it']):
            data["category"] = "Software"
        elif any(w in name for w in ['market','seo','ads','media','marketing']):
            data["category"] = "Marketing"
        elif any(w in name for w in ['legal','law','consult','edge']):
            data["category"] = "Legal"
        elif any(w in name for w in ['office','supply','furniture','direct']):
            data["category"] = "Operations"
        elif any(w in name for w in ['infra','ops','server','cloud']):
            data["category"] = "Software"

    return data


def generate_invoice_summary(invoice_data: dict) -> str:
    vendor = invoice_data.get('vendor_name') or 'Unknown vendor'
    total = invoice_data.get('total_amount', 0)
    currency = invoice_data.get('currency', 'USD')
    date = invoice_data.get('invoice_date') or 'unknown date'
    return f"Invoice from {vendor} for {currency} {total:.2f} dated {date}."


def detect_fraud(invoice_data: dict, existing_invoices: list) -> dict:
    flags = []
    for existing in existing_invoices:
        if (existing.get("total_amount") == invoice_data.get("total_amount") and
            existing.get("vendor_name") == invoice_data.get("vendor_name") and
            invoice_data.get("total_amount", 0) > 0):
            flags.append("Duplicate payment detected")
            break
    if not invoice_data.get("vendor_name"):
        flags.append("Vendor name missing")
    if not invoice_data.get("invoice_number"):
        flags.append("Invoice number missing")
    if invoice_data.get("total_amount", 0) <= 0:
        flags.append("Total amount is zero")
    return {"is_flagged": len(flags) > 0, "flags": flags}


def _empty_invoice(error: str) -> dict:
    return {
        "vendor_name": None, "invoice_number": None,
        "invoice_date": None, "due_date": None,
        "subtotal": 0.0, "tax_amount": 0.0, "total_amount": 0.0,
        "currency": "USD", "bank_account": None, "category": "Other",
        "line_items": [], "confidence_score": 0.0, "_error": error
    }