import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sqlalchemy.orm import Session
from app.models.models import Invoice
from datetime import datetime, timedelta
import calendar

def get_monthly_spend(user_id: int, db: Session) -> list:
    """Get monthly spend data from database."""
    invoices = db.query(Invoice).filter(
        Invoice.user_id == user_id,
        Invoice.total_amount > 0
    ).all()

    if not invoices:
        return []

    monthly = {}
    for inv in invoices:
        if inv.created_at:
            key = inv.created_at.strftime("%Y-%m")
            monthly[key] = monthly.get(key, 0) + inv.total_amount

    return [{"month": k, "total": round(v, 2)} for k, v in sorted(monthly.items())]

def forecast_next_months(user_id: int, db: Session, months_ahead: int = 3) -> dict:
    """Train ML model and forecast future spending."""
    monthly_data = get_monthly_spend(user_id, db)

    # Need at least 2 data points to forecast
    if len(monthly_data) < 2:
        # Generate forecast based on current data
        invoices = db.query(Invoice).filter(
            Invoice.user_id == user_id,
            Invoice.total_amount > 0
        ).all()

        if not invoices:
            return {"error": "No invoice data available for forecasting"}

        avg_spend = sum(i.total_amount for i in invoices) / max(len(invoices), 1)
        monthly_avg = avg_spend * 5  # estimate monthly

        forecasts = []
        today = datetime.utcnow()
        for i in range(1, months_ahead + 1):
            future_date = today + timedelta(days=30 * i)
            variation = monthly_avg * 0.1 * (i - 1)
            forecasts.append({
                "month": future_date.strftime("%b %Y"),
                "predicted": round(monthly_avg + variation, 2),
                "lower": round((monthly_avg + variation) * 0.85, 2),
                "upper": round((monthly_avg + variation) * 1.15, 2),
            })

        return {
            "historical": monthly_data,
            "forecasts": forecasts,
            "model": "average_based",
            "accuracy": None,
            "insight": f"Based on your current invoices, estimated monthly spend is ${monthly_avg:,.2f}"
        }

    # Build ML model with enough data
    amounts = [d["total"] for d in monthly_data]
    X = np.array(range(len(amounts))).reshape(-1, 1)
    y = np.array(amounts)

    # Use polynomial features for better fit
    if len(amounts) >= 4:
        poly = PolynomialFeatures(degree=2)
        X_poly = poly.fit_transform(X)
        model = LinearRegression()
        model.fit(X_poly, y)

        # Predict future
        forecasts = []
        today = datetime.utcnow()
        for i in range(1, months_ahead + 1):
            future_idx = np.array([[len(amounts) + i - 1]])
            future_poly = poly.transform(future_idx)
            predicted = float(model.predict(future_poly)[0])
            predicted = max(predicted, 0)

            future_date = today + timedelta(days=30 * i)
            forecasts.append({
                "month": future_date.strftime("%b %Y"),
                "predicted": round(predicted, 2),
                "lower": round(predicted * 0.85, 2),
                "upper": round(predicted * 1.15, 2),
            })

        # Calculate R2 score
        from sklearn.metrics import r2_score
        y_pred = model.predict(poly.transform(X))
        r2 = r2_score(y, y_pred)
        accuracy = round(max(r2, 0) * 100, 1)

    else:
        # Simple linear regression
        model = LinearRegression()
        model.fit(X, y)

        forecasts = []
        today = datetime.utcnow()
        for i in range(1, months_ahead + 1):
            future_idx = np.array([[len(amounts) + i - 1]])
            predicted = float(model.predict(future_idx)[0])
            predicted = max(predicted, 0)

            future_date = today + timedelta(days=30 * i)
            forecasts.append({
                "month": future_date.strftime("%b %Y"),
                "predicted": round(predicted, 2),
                "lower": round(predicted * 0.85, 2),
                "upper": round(predicted * 1.15, 2),
            })

        from sklearn.metrics import r2_score
        y_pred = model.predict(X)
        r2 = r2_score(y, y_pred)
        accuracy = round(max(r2, 0) * 100, 1)

    # Generate insight
    last_spend = amounts[-1]
    next_predicted = forecasts[0]["predicted"]
    change = ((next_predicted - last_spend) / last_spend * 100) if last_spend > 0 else 0
    direction = "increase" if change > 0 else "decrease"

    insight = f"Model predicts a {abs(change):.1f}% {direction} in spending next month. Forecasted: ${next_predicted:,.2f}"

    return {
        "historical": monthly_data,
        "forecasts": forecasts,
        "model": "linear_regression",
        "accuracy": accuracy,
        "insight": insight
    }