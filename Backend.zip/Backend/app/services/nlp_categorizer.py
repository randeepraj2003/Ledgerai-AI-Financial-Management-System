import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
import numpy as np

# Training data - vendor names and descriptions mapped to categories
TRAINING_DATA = [
    # Software
    ("microsoft software license azure cloud", "Software"),
    ("amazon web services aws hosting", "Software"),
    ("google cloud platform subscription", "Software"),
    ("adobe creative suite license", "Software"),
    ("salesforce crm subscription", "Software"),
    ("github enterprise license", "Software"),
    ("slack workspace subscription", "Software"),
    ("zoom video conferencing", "Software"),
    ("techsoft solutions software", "Software"),
    ("cloudops infrastructure hosting", "Software"),
    ("digital ocean server hosting", "Software"),
    ("heroku platform subscription", "Software"),
    ("datadog monitoring service", "Software"),
    ("jira project management tool", "Software"),
    ("notion workspace license", "Software"),

    # Marketing
    ("google ads campaign management", "Marketing"),
    ("facebook meta advertising", "Marketing"),
    ("digital marketing agency seo", "Marketing"),
    ("content creation social media", "Marketing"),
    ("email marketing mailchimp", "Marketing"),
    ("hubspot marketing platform", "Marketing"),
    ("seo optimization service", "Marketing"),
    ("brand design creative agency", "Marketing"),
    ("digital marketing pro services", "Marketing"),
    ("influencer campaign management", "Marketing"),
    ("pr public relations agency", "Marketing"),
    ("copywriting content services", "Marketing"),

    # Legal
    ("legal consulting attorney fees", "Legal"),
    ("law firm retainer services", "Legal"),
    ("contract review legal advice", "Legal"),
    ("trademark patent registration", "Legal"),
    ("compliance regulatory consulting", "Legal"),
    ("legaledge consultants services", "Legal"),
    ("corporate legal advisory", "Legal"),
    ("intellectual property protection", "Legal"),
    ("employment law consultation", "Legal"),
    ("business registration services", "Legal"),

    # Operations
    ("office supplies stationery", "Operations"),
    ("furniture equipment purchase", "Operations"),
    ("laptop computer hardware", "Operations"),
    ("printer scanner equipment", "Operations"),
    ("office rent utilities", "Operations"),
    ("cleaning maintenance service", "Operations"),
    ("officesupply direct purchase", "Operations"),
    ("courier delivery logistics", "Operations"),
    ("security system installation", "Operations"),
    ("phone telephone service", "Operations"),
    ("electricity water utilities", "Operations"),

    # HR
    ("recruitment agency staffing", "HR"),
    ("payroll processing services", "HR"),
    ("employee training workshop", "HR"),
    ("hr consulting human resources", "HR"),
    ("background check screening", "HR"),
    ("benefits administration health", "HR"),
    ("team building event management", "HR"),

    # Finance
    ("accounting bookkeeping services", "Finance"),
    ("tax preparation filing", "Finance"),
    ("audit financial review", "Finance"),
    ("banking transaction fees", "Finance"),
    ("insurance premium payment", "Finance"),
    ("financial advisory consulting", "Finance"),
    ("expense management software", "Finance"),
]

# Build and train the NLP pipeline
def build_model():
    texts = [item[0] for item in TRAINING_DATA]
    labels = [item[1] for item in TRAINING_DATA]

    pipeline = Pipeline([
        ('tfidf', TfidfVectorizer(
            ngram_range=(1, 2),
            max_features=500,
            stop_words='english',
            lowercase=True
        )),
        ('classifier', MultinomialNB(alpha=0.1))
    ])

    pipeline.fit(texts, labels)
    return pipeline

# Train model once when module loads
_model = build_model()

def categorize_invoice(vendor_name: str, invoice_text: str = "") -> dict:
    """
    Categorize an invoice using NLP TF-IDF + Naive Bayes classifier.
    Returns category and confidence score.
    """
    # Combine vendor name and any text for better classification
    combined_text = f"{vendor_name} {invoice_text}".lower().strip()

    if not combined_text.strip():
        return {"category": "Other", "confidence": 0.0, "method": "default"}

    # Clean text
    combined_text = re.sub(r'[^a-zA-Z0-9\s]', ' ', combined_text)
    combined_text = re.sub(r'\s+', ' ', combined_text).strip()

    try:
        # Get prediction and probability
        prediction = _model.predict([combined_text])[0]
        probabilities = _model.predict_proba([combined_text])[0]
        confidence = float(np.max(probabilities))

        return {
            "category": prediction,
            "confidence": round(confidence * 100, 1),
            "method": "nlp_tfidf_naive_bayes"
        }
    except Exception as e:
        # Fallback to keyword matching
        return _keyword_fallback(vendor_name)

def _keyword_fallback(vendor_name: str) -> dict:
    """Fallback keyword matching if NLP fails."""
    name = vendor_name.lower()
    if any(w in name for w in ['tech', 'software', 'cloud', 'digital', 'it', 'ops']):
        return {"category": "Software", "confidence": 60.0, "method": "keyword"}
    elif any(w in name for w in ['market', 'seo', 'ads', 'media', 'creative']):
        return {"category": "Marketing", "confidence": 60.0, "method": "keyword"}
    elif any(w in name for w in ['legal', 'law', 'consult', 'attorney']):
        return {"category": "Legal", "confidence": 60.0, "method": "keyword"}
    elif any(w in name for w in ['office', 'supply', 'furniture', 'equipment']):
        return {"category": "Operations", "confidence": 60.0, "method": "keyword"}
    elif any(w in name for w in ['hr', 'recruit', 'staffing', 'payroll']):
        return {"category": "HR", "confidence": 60.0, "method": "keyword"}
    elif any(w in name for w in ['account', 'tax', 'audit', 'finance']):
        return {"category": "Finance", "confidence": 60.0, "method": "keyword"}
    return {"category": "Other", "confidence": 0.0, "method": "default"}

def batch_categorize(invoices: list) -> list:
    """Categorize multiple invoices at once."""
    results = []
    for inv in invoices:
        vendor = inv.get("vendor_name") or ""
        result = categorize_invoice(vendor)
        results.append({
            "id": inv.get("id"),
            "vendor": vendor,
            "old_category": inv.get("category", "Other"),
            "new_category": result["category"],
            "confidence": result["confidence"],
            "method": result["method"]
        })
    return results