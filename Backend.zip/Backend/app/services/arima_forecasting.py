import numpy as np
import pandas as pd
from sqlalchemy.orm import Session
from app.models.models import Invoice
from datetime import datetime, timedelta

def arima_forecast(user_id: int, db: Session, months_ahead: int = 3) -> dict:
    """
    ARIMA Time Series forecasting for monthly spend prediction.
    Falls back to exponential smoothing if insufficient data.
    """
    invoices = db.query(Invoice).filter(
        Invoice.user_id == user_id,
        Invoice.total_amount > 0
    ).all()

    if not invoices:
        return {
            "status": "no_data",
            "message": "No invoice data available.",
            "forecasts": []
        }

    # Build monthly time series
    monthly = {}
    for inv in invoices:
        if inv.created_at:
            key = inv.created_at.strftime("%Y-%m")
            monthly[key] = monthly.get(key, 0) + inv.total_amount

    monthly_series = [(k, round(v, 2)) for k, v in sorted(monthly.items())]

    if len(monthly_series) < 2:
        # Not enough history — use average-based forecast
        avg = np.mean([v for _, v in monthly_series]) if monthly_series else 0
        today = datetime.utcnow()
        forecasts = []
        for i in range(1, months_ahead + 1):
            future = today + timedelta(days=30 * i)
            forecasts.append({
                "month": future.strftime("%b %Y"),
                "predicted": round(avg, 2),
                "lower": round(avg * 0.85, 2),
                "upper": round(avg * 1.15, 2),
                "method": "average"
            })
        return {
            "status": "success",
            "historical": [{"month": k, "total": v} for k, v in monthly_series],
            "forecasts": forecasts,
            "model": "Average-based (insufficient history for ARIMA)",
            "insight": f"Based on available data, estimated monthly spend is ${avg:,.2f}"
        }

    # Try ARIMA first
    values = [v for _, v in monthly_series]

    try:
        from statsmodels.tsa.arima.model import ARIMA
        from statsmodels.tsa.stattools import adfuller
        import warnings
        warnings.filterwarnings('ignore')

        # Check stationarity
        series = pd.Series(values)

        # Try ARIMA(1,1,1) — good general purpose model
        model = ARIMA(series, order=(1, 1, 1))
        fitted = model.fit()

        # Forecast
        forecast_result = fitted.forecast(steps=months_ahead)
        conf_int = fitted.get_forecast(steps=months_ahead).conf_int(alpha=0.2)

        today = datetime.utcnow()
        forecasts = []
        for i in range(months_ahead):
            future = today + timedelta(days=30 * (i + 1))
            predicted = max(float(forecast_result.iloc[i]), 0)
            lower = max(float(conf_int.iloc[i, 0]), 0)
            upper = max(float(conf_int.iloc[i, 1]), 0)

            forecasts.append({
                "month": future.strftime("%b %Y"),
                "predicted": round(predicted, 2),
                "lower": round(lower, 2),
                "upper": round(upper, 2),
                "method": "arima"
            })

        # Calculate model fit
        aic = round(fitted.aic, 2)
        last = values[-1]
        next_pred = forecasts[0]["predicted"]
        change_pct = ((next_pred - last) / last * 100) if last > 0 else 0
        direction = "increase" if change_pct > 0 else "decrease"

        return {
            "status": "success",
            "historical": [{"month": k, "total": v} for k, v in monthly_series],
            "forecasts": forecasts,
            "model": "ARIMA(1,1,1)",
            "aic_score": aic,
            "insight": f"ARIMA predicts a {abs(change_pct):.1f}% {direction} next month. Forecasted: ${next_pred:,.2f}"
        }

    except Exception as e:
        # Fallback to Exponential Smoothing
        try:
            from statsmodels.tsa.holtwinters import SimpleExpSmoothing
            import warnings
            warnings.filterwarnings('ignore')

            series = pd.Series(values)
            model = SimpleExpSmoothing(series).fit(smoothing_level=0.3)
            forecast_vals = model.forecast(months_ahead)

            today = datetime.utcnow()
            forecasts = []
            for i in range(months_ahead):
                future = today + timedelta(days=30 * (i + 1))
                predicted = max(float(forecast_vals.iloc[i]), 0)
                forecasts.append({
                    "month": future.strftime("%b %Y"),
                    "predicted": round(predicted, 2),
                    "lower": round(predicted * 0.85, 2),
                    "upper": round(predicted * 1.15, 2),
                    "method": "exponential_smoothing"
                })

            last = values[-1]
            next_pred = forecasts[0]["predicted"]
            change_pct = ((next_pred - last) / last * 100) if last > 0 else 0
            direction = "increase" if change_pct > 0 else "decrease"

            return {
                "status": "success",
                "historical": [{"month": k, "total": v} for k, v in monthly_series],
                "forecasts": forecasts,
                "model": "Exponential Smoothing",
                "insight": f"Model predicts a {abs(change_pct):.1f}% {direction} next month. Forecasted: ${next_pred:,.2f}"
            }

        except Exception as e2:
            return {
                "status": "error",
                "message": str(e2),
                "forecasts": []
            }