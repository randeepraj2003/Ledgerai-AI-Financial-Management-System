import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import cross_val_score
from sklearn.metrics import mean_absolute_error
from sqlalchemy.orm import Session
from app.models.models import Invoice

def predict_invoice_amounts(user_id: int, db: Session) -> dict:
    """
    Random Forest Regression to predict expected invoice amounts.
    Flags invoices where actual amount differs significantly from prediction.
    """
    invoices = db.query(Invoice).filter(
        Invoice.user_id == user_id,
        Invoice.total_amount > 0
    ).all()

    if len(invoices) < 4:
        return {
            "status": "insufficient_data",
            "message": f"Need at least 4 invoices for Random Forest prediction. You have {len(invoices)}.",
            "predictions": [],
            "model_performance": {}
        }

    # Build dataframe
    data = []
    for inv in invoices:
        data.append({
            "id": inv.id,
            "vendor": inv.vendor_name or "Unknown",
            "category": inv.category or "Other",
            "month": inv.created_at.month if inv.created_at else 1,
            "quarter": ((inv.created_at.month - 1) // 3 + 1) if inv.created_at else 1,
            "tax_amount": inv.tax_amount or 0,
            "subtotal": inv.subtotal or 0,
            "total_amount": inv.total_amount,
            "status": inv.status or "pending"
        })

    df = pd.DataFrame(data)

    # Encode categorical features
    le_vendor = LabelEncoder()
    le_category = LabelEncoder()
    le_status = LabelEncoder()

    df["vendor_enc"] = le_vendor.fit_transform(df["vendor"])
    df["category_enc"] = le_category.fit_transform(df["category"])
    df["status_enc"] = le_status.fit_transform(df["status"])

    # Feature matrix
    feature_cols = ["vendor_enc", "category_enc", "month", "quarter", "tax_amount", "status_enc"]
    X = df[feature_cols].values
    y = df["total_amount"].values

    # Train Random Forest
    rf_model = RandomForestRegressor(
        n_estimators=100,
        max_depth=5,
        random_state=42,
        min_samples_split=2
    )
    rf_model.fit(X, y)

    # Predict for all invoices
    predictions = rf_model.predict(X)
    mae = mean_absolute_error(y, predictions)

    # Feature importance
    feature_importance = dict(zip(feature_cols, rf_model.feature_importances_))
    top_features = sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)

    # Flag invoices with large deviation
    results = []
    for i, row in df.iterrows():
        actual = row["total_amount"]
        predicted = float(predictions[i])
        deviation = abs(actual - predicted)
        deviation_pct = (deviation / predicted * 100) if predicted > 0 else 0

        is_unusual = deviation_pct > 30 and deviation > 500

        results.append({
            "id": int(row["id"]),
            "vendor": row["vendor"],
            "category": row["category"],
            "actual_amount": round(actual, 2),
            "predicted_amount": round(predicted, 2),
            "deviation": round(deviation, 2),
            "deviation_pct": round(deviation_pct, 1),
            "is_unusual": is_unusual,
            "verdict": "Unusual - Review needed" if is_unusual else "Normal"
        })

    unusual = [r for r in results if r["is_unusual"]]
    normal = [r for r in results if not r["is_unusual"]]

    return {
        "status": "success",
        "predictions": results,
        "unusual_invoices": unusual,
        "normal_invoices": normal,
        "model_performance": {
            "mae": round(mae, 2),
            "total_invoices": len(invoices),
            "unusual_count": len(unusual),
            "normal_count": len(normal),
            "top_features": [{"feature": f, "importance": round(v * 100, 1)} for f, v in top_features[:3]]
        },
        "model": "Random Forest Regressor",
        "n_estimators": 100
    }