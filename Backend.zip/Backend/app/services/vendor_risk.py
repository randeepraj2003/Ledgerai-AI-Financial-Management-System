import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sqlalchemy.orm import Session
from app.models.models import Invoice

def calculate_vendor_risk(user_id: int, db: Session) -> dict:
    """
    Score each vendor 0-100 using K-Means clustering based on:
    - Total spend amount
    - Invoice frequency
    - Amount consistency (std deviation)
    - Average invoice size
    """
    invoices = db.query(Invoice).filter(
        Invoice.user_id == user_id,
        Invoice.total_amount > 0
    ).all()

    if len(invoices) < 2:
        return {
            "status": "insufficient_data",
            "message": "Need at least 2 invoices for vendor risk scoring.",
            "vendors": []
        }

    # Build vendor profile
    vendor_data = {}
    for inv in invoices:
        vendor = inv.vendor_name or "Unknown"
        if vendor not in vendor_data:
            vendor_data[vendor] = {
                "amounts": [],
                "statuses": [],
                "categories": []
            }
        vendor_data[vendor]["amounts"].append(inv.total_amount)
        vendor_data[vendor]["statuses"].append(inv.status)
        vendor_data[vendor]["categories"].append(inv.category or "Other")

    # Calculate features per vendor
    vendor_profiles = []
    for vendor, data in vendor_data.items():
        amounts = data["amounts"]
        flagged_count = sum(1 for s in data["statuses"] if s == "flagged")
        rejected_count = sum(1 for s in data["statuses"] if s == "rejected")

        profile = {
            "vendor": vendor,
            "total_spend": round(sum(amounts), 2),
            "invoice_count": len(amounts),
            "avg_amount": round(np.mean(amounts), 2),
            "std_amount": round(np.std(amounts), 2) if len(amounts) > 1 else 0,
            "max_amount": round(max(amounts), 2),
            "flagged_count": flagged_count,
            "rejected_count": rejected_count,
            "category": data["categories"][0]
        }
        vendor_profiles.append(profile)

    if len(vendor_profiles) < 2:
        # Single vendor — calculate risk manually
        p = vendor_profiles[0]
        risk_score = min(100, p["flagged_count"] * 30 + p["rejected_count"] * 20 + 10)
        return {
            "status": "success",
            "vendors": [{
                **p,
                "risk_score": risk_score,
                "risk_level": _get_risk_level(risk_score),
                "cluster": 0
            }],
            "summary": {"high_risk": 0, "medium_risk": 0, "low_risk": 1}
        }

    # Build feature matrix for K-Means
    df = pd.DataFrame(vendor_profiles)
    features = ["total_spend", "invoice_count", "avg_amount", "std_amount", "flagged_count"]
    X = df[features].fillna(0)

    # Normalize features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # K-Means clustering into 3 groups (low/medium/high risk)
    n_clusters = min(3, len(vendor_profiles))
    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    clusters = kmeans.fit_predict(X_scaled)
    df["cluster"] = clusters

    # Calculate risk score 0-100 for each vendor
    def calc_risk(row):
        score = 0
        # High spend = higher risk
        spend_pct = row["total_spend"] / df["total_spend"].max() if df["total_spend"].max() > 0 else 0
        score += spend_pct * 30

        # High std deviation = inconsistent amounts = risky
        if df["std_amount"].max() > 0:
            std_pct = row["std_amount"] / df["std_amount"].max()
            score += std_pct * 25

        # Flagged invoices = very risky
        score += min(row["flagged_count"] * 20, 30)

        # Rejected invoices = risky
        score += min(row["rejected_count"] * 15, 15)

        return round(min(score, 100), 1)

    df["risk_score"] = df.apply(calc_risk, axis=1)

    # Build response
    vendors_list = []
    for _, row in df.sort_values("risk_score", ascending=False).iterrows():
        vendors_list.append({
            "vendor": row["vendor"],
            "total_spend": float(row["total_spend"]),
            "invoice_count": int(row["invoice_count"]),
            "avg_amount": float(row["avg_amount"]),
            "flagged_count": int(row["flagged_count"]),
            "rejected_count": int(row["rejected_count"]),
            "risk_score": float(row["risk_score"]),
            "risk_level": _get_risk_level(row["risk_score"]),
            "category": row["category"],
            "cluster": int(row["cluster"])
        })

    high_risk = sum(1 for v in vendors_list if v["risk_score"] >= 60)
    medium_risk = sum(1 for v in vendors_list if 30 <= v["risk_score"] < 60)
    low_risk = sum(1 for v in vendors_list if v["risk_score"] < 30)

    return {
        "status": "success",
        "vendors": vendors_list,
        "summary": {
            "high_risk": high_risk,
            "medium_risk": medium_risk,
            "low_risk": low_risk
        },
        "model": "K-Means Clustering",
        "features_used": features
    }

def _get_risk_level(score: float) -> str:
    if score >= 60:
        return "HIGH"
    elif score >= 30:
        return "MEDIUM"
    else:
        return "LOW"