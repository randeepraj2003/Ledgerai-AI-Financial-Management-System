from pydantic_settings import BaseSettings
 
class Settings(BaseSettings):
    ANTHROPIC_API_KEY: str
    DATABASE_URL: str = "postgresql://postgres:password@localhost:5432/finance_dashboard"
    SECRET_KEY: str = "change-this-secret-key"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    FRONTEND_URL: str = "http://localhost:5173"
    REDIS_URL: str = "redis://localhost:6379"
    UPLOAD_DIR: str = "./uploads"
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USER: str = ""
    SMTP_PASSWORD: str = ""
    FROM_EMAIL: str = ""
 
    class Config:
        env_file = ".env"
        extra = "ignore"     # ← only change, ignores GEMINI_API_KEY
 
settings = Settings()
