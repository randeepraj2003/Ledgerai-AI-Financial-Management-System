import axios from 'axios'

const api = axios.create({ baseURL: 'http://localhost:8000' })

api.interceptors.request.use(config => {
  const token = localStorage.getItem('token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token')
      localStorage.removeItem('user')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

// Auth
export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  me: () => api.get('/auth/me'),
}

// Invoices
export const invoicesAPI = {
  upload: (file) => {
    const form = new FormData()
    form.append('file', file)
    return api.post('/invoices/upload', form, { headers: { 'Content-Type': 'multipart/form-data' } })
  },
  list: (status) => api.get('/invoices/', { params: status ? { status } : {} }),
  get: (id) => api.get(`/invoices/${id}`),
  update: (id, data) => api.patch(`/invoices/${id}`, data),
  delete: (id) => api.delete(`/invoices/${id}`),
}

// Analytics
export const analyticsAPI = {
  summary: () => api.get('/analytics/summary'),
}

// AI Chat
export const chatAPI = {
  send: (message) => api.post('/ai/chat', { message }),
  history: () => api.get('/ai/history'),
}

// Reports
export const reportsAPI = {
  exportExcel: () => api.get('/reports/export/excel', { responseType: 'blob' }),
}

// Forecast
export const forecastAPI = {
  get: (months = 3) => api.get(`/analytics/forecast?months=${months}`),
}

// Anomaly Detection
export const anomalyAPI = {
  get: () => api.get('/analytics/anomalies'),
}
export const vendorRiskAPI = { get: () => api.get('/analytics/vendor-risk') }
export const duplicateAPI = { get: () => api.get('/analytics/duplicates') }
export const categorizeAPI = { run: () => api.post('/analytics/categorize') }
export const randomForestAPI = { get: () => api.get('/analytics/random-forest') }
export const dbscanAPI = { get: () => api.get('/analytics/spending-patterns') }
export const arimaAPI = { get: (months = 3) => api.get(`/analytics/arima-forecast?months=${months}`) }
export default api

