import { useEffect, useState, useCallback } from 'react'
import { useDropzone } from 'react-dropzone'
import { invoicesAPI } from '../services/api'

const STATUS_FILTERS = ['all', 'pending', 'approved', 'flagged', 'rejected']

function UploadZone({ onUpload }) {
  const [uploading, setUploading] = useState(false)
  const [message, setMessage] = useState('')

  const onDrop = useCallback(async (files) => {
    if (!files.length) return
    setUploading(true)
    setMessage('')
    let success = 0
    for (const file of files) {
      try {
        await invoicesAPI.upload(file)
        success++
      } catch { setMessage(`Failed to upload ${file.name}`) }
    }
    if (success) { setMessage(`${success} invoice(s) uploaded — AI is processing…`); onUpload() }
    setUploading(false)
  }, [onUpload])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop, accept: { 'application/pdf': ['.pdf'] }, multiple: true, disabled: uploading
  })

  return (
    <div>
      <div {...getRootProps()} style={{
        border: `2px dashed ${isDragActive ? 'var(--accent)' : 'var(--border)'}`,
        borderRadius: 12, padding: '28px 20px', textAlign: 'center', cursor: 'pointer',
        background: isDragActive ? 'rgba(79,142,247,0.06)' : 'var(--bg2)',
        transition: 'all 0.15s', marginBottom: message ? 10 : 0
      }}>
        <input {...getInputProps()} />
        <div style={{ fontSize: 28, marginBottom: 8 }}>📄</div>
        {uploading
          ? <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}><div className="spinner" />Processing upload…</div>
          : <div>
              <div style={{ fontWeight: 500, marginBottom: 4 }}>{isDragActive ? 'Drop PDFs here' : 'Drop PDF invoices here'}</div>
              <div style={{ fontSize: 12, color: 'var(--text3)' }}>or click to browse — AI will extract and analyze automatically</div>
            </div>
        }
      </div>
      {message && <div style={{ fontSize: 13, color: message.startsWith('Failed') ? 'var(--red)' : 'var(--green)', padding: '8px 12px', background: message.startsWith('Failed') ? 'rgba(248,113,113,0.08)' : 'rgba(52,211,153,0.08)', borderRadius: 8, border: `1px solid ${message.startsWith('Failed') ? 'rgba(248,113,113,0.2)' : 'rgba(52,211,153,0.2)'}` }}>{message}</div>}
    </div>
  )
}

function InvoiceRow({ invoice, onUpdate, onDelete }) {
  const [loading, setLoading] = useState(false)

  const approve = async () => {
    setLoading(true)
    await invoicesAPI.update(invoice.id, { status: 'approved' })
    onUpdate()
    setLoading(false)
  }
  const reject = async () => {
    setLoading(true)
    await invoicesAPI.update(invoice.id, { status: 'rejected' })
    onUpdate()
    setLoading(false)
  }
  const remove = async () => {
    if (!confirm('Delete this invoice?')) return
    await invoicesAPI.delete(invoice.id)
    onDelete()
  }

  return (
    <tr style={{ borderBottom: '1px solid var(--border)' }}>
      <td style={{ padding: '14px 0' }}>
        <div style={{ fontWeight: 500, fontSize: 14 }}>{invoice.vendor_name || <span style={{ color: 'var(--text3)' }}>Processing…</span>}</div>
        <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>{invoice.file_name}</div>
      </td>
      <td style={{ padding: '14px 12px', fontSize: 13, color: 'var(--text2)' }}>{invoice.invoice_number || '—'}</td>
      <td style={{ padding: '14px 12px', fontSize: 13, color: 'var(--text2)' }}>{invoice.invoice_date || '—'}</td>
      <td style={{ padding: '14px 12px', fontFamily: 'var(--mono)', fontSize: 13 }}>
        {invoice.total_amount > 0 ? `${invoice.currency} ${invoice.total_amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '—'}
      </td>
      <td style={{ padding: '14px 12px' }}>
        <span className={`badge badge-${invoice.status}`}>{invoice.status}</span>
      </td>
      <td style={{ padding: '14px 12px' }}>
        {invoice.fraud_flags?.length > 0
          ? <div title={invoice.fraud_flags.join(', ')} style={{ color: 'var(--red)', fontSize: 12, cursor: 'help' }}>⚠ {invoice.fraud_flags.length} flag{invoice.fraud_flags.length > 1 ? 's' : ''}</div>
          : <span style={{ color: 'var(--text3)', fontSize: 12 }}>None</span>}
      </td>
      <td style={{ padding: '14px 0' }}>
        <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
          {invoice.status === 'pending' || invoice.status === 'flagged' ? <>
            <button className="btn" onClick={approve} disabled={loading} style={{ fontSize: 12, padding: '5px 10px', color: 'var(--green)', borderColor: 'rgba(52,211,153,0.3)' }}>Approve</button>
            <button className="btn" onClick={reject} disabled={loading} style={{ fontSize: 12, padding: '5px 10px', color: 'var(--red)', borderColor: 'rgba(248,113,113,0.3)' }}>Reject</button>
          </> : null}
          <button className="btn" onClick={remove} style={{ fontSize: 12, padding: '5px 10px', color: 'var(--text3)' }}>✕</button>
        </div>
      </td>
    </tr>
  )
}

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState([])
  const [filter, setFilter] = useState('all')
  const [loading, setLoading] = useState(true)

  const fetchInvoices = async () => {
    setLoading(true)
    try {
      const res = await invoicesAPI.list(filter === 'all' ? null : filter)
      setInvoices(res.data)
    } finally { setLoading(false) }
  }

  useEffect(() => { fetchInvoices() }, [filter])

  // Auto-refresh every 5s if there are pending invoices being processed
  useEffect(() => {
    const hasPending = invoices.some(i => !i.vendor_name && i.status === 'pending')
    if (!hasPending) return
    const timer = setTimeout(fetchInvoices, 5000)
    return () => clearTimeout(timer)
  }, [invoices])

  return (
    <div className="animate-in">
      <div style={{ marginBottom: 24 }}>
        <h1 className="page-title">Invoices</h1>
        <p className="page-subtitle">Upload PDFs — AI extracts, categorizes, and checks for fraud automatically</p>
      </div>

      <div style={{ marginBottom: 20 }}>
        <UploadZone onUpload={fetchInvoices} />
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {STATUS_FILTERS.map(s => (
          <button key={s} onClick={() => setFilter(s)} className="btn" style={{
            fontSize: 12, padding: '5px 12px',
            background: filter === s ? 'var(--accent)' : 'var(--bg2)',
            borderColor: filter === s ? 'var(--accent)' : 'var(--border)',
            color: filter === s ? '#fff' : 'var(--text2)'
          }}>{s.charAt(0).toUpperCase() + s.slice(1)}</button>
        ))}
        <div style={{ marginLeft: 'auto', fontSize: 13, color: 'var(--text3)', display: 'flex', alignItems: 'center' }}>
          {invoices.length} invoice{invoices.length !== 1 ? 's' : ''}
        </div>
      </div>

      {/* Table */}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        {loading
          ? <div style={{ padding: 40, textAlign: 'center' }}><div className="spinner" style={{ margin: '0 auto' }} /></div>
          : <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', padding: '0 24px' }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid var(--border)' }}>
                    {['Vendor', 'Invoice #', 'Date', 'Amount', 'Status', 'Flags', ''].map(h => (
                      <th key={h} style={{ textAlign: h === '' ? 'right' : 'left', padding: '14px 12px', fontSize: 12, color: 'var(--text3)', fontWeight: 500, whiteSpace: 'nowrap', ...(h === 'Vendor' ? { paddingLeft: 24 } : {}), ...(h === '' ? { paddingRight: 24 } : {}) }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {invoices.map(inv => (
                    <tr key={inv.id} style={{ borderBottom: '1px solid var(--border)' }}>
                      <td style={{ padding: '14px 12px 14px 24px' }}>
                        <div style={{ fontWeight: 500, fontSize: 14 }}>{inv.vendor_name || <span style={{ color: 'var(--text3)' }}>Processing…</span>}</div>
                        <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>{inv.file_name}</div>
                      </td>
                      <td style={{ padding: '14px 12px', fontSize: 13, color: 'var(--text2)' }}>{inv.invoice_number || '—'}</td>
                      <td style={{ padding: '14px 12px', fontSize: 13, color: 'var(--text2)' }}>{inv.invoice_date || '—'}</td>
                      <td style={{ padding: '14px 12px', fontFamily: 'var(--mono)', fontSize: 13 }}>
                        {inv.total_amount > 0 ? `${inv.currency} ${inv.total_amount.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '—'}
                      </td>
                      <td style={{ padding: '14px 12px' }}><span className={`badge badge-${inv.status}`}>{inv.status}</span></td>
                      <td style={{ padding: '14px 12px' }}>
                        {inv.fraud_flags?.length > 0
                          ? <div title={inv.fraud_flags.join('\n')} style={{ color: 'var(--red)', fontSize: 12, cursor: 'help' }}>⚠ {inv.fraud_flags.length} flag{inv.fraud_flags.length > 1 ? 's' : ''}</div>
                          : <span style={{ color: 'var(--text3)', fontSize: 12 }}>None</span>}
                      </td>
                      <td style={{ padding: '14px 24px 14px 12px' }}>
                        <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                          {(inv.status === 'pending' || inv.status === 'flagged') && <>
                            <button className="btn" onClick={async () => { await invoicesAPI.update(inv.id, { status: 'approved' }); fetchInvoices() }} style={{ fontSize: 12, padding: '5px 10px', color: 'var(--green)', borderColor: 'rgba(52,211,153,0.3)' }}>✓ Approve</button>
                            <button className="btn" onClick={async () => { await invoicesAPI.update(inv.id, { status: 'rejected' }); fetchInvoices() }} style={{ fontSize: 12, padding: '5px 10px', color: 'var(--red)', borderColor: 'rgba(248,113,113,0.3)' }}>✕ Reject</button>
                          </>}
                          <button className="btn" onClick={async () => { if (confirm('Delete?')) { await invoicesAPI.delete(inv.id); fetchInvoices() } }} style={{ fontSize: 12, padding: '5px 10px', color: 'var(--text3)' }}>🗑</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {!invoices.length && (
                    <tr><td colSpan={7} style={{ padding: '48px 24px', textAlign: 'center', color: 'var(--text3)', fontSize: 14 }}>
                      No invoices found. Upload a PDF above to get started.
                    </td></tr>
                  )}
                </tbody>
              </table>
            </div>
        }
      </div>
    </div>
  )
}
