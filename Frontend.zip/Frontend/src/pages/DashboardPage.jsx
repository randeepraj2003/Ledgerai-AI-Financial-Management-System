import { useEffect, useState } from 'react'
import { BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, ZAxis } from 'recharts'
import { analyticsAPI, reportsAPI, forecastAPI, anomalyAPI, vendorRiskAPI, duplicateAPI, categorizeAPI, randomForestAPI, dbscanAPI, arimaAPI } from '../services/api'
import { useAuth } from '../hooks/useAuth'

const COLORS = ['#4f8ef7', '#34d399', '#fbbf24', '#a78bfa', '#f87171', '#fb923c', '#22d3ee', '#e879f9']

function KpiCard({ label, value, sub, color }) {
  return (
    <div className="card" style={{ flex: 1, minWidth: 160 }}>
      <div style={{ fontSize: 12, color: 'var(--text2)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.06em' }}>{label}</div>
      <div style={{ fontSize: 26, fontWeight: 600, color: color || 'var(--text)', lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 6 }}>{sub}</div>}
    </div>
  )
}

function SectionHeader({ title, subtitle, badge, badgeColor }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
      <div>
        <div style={{ fontWeight: 500, fontSize: 15 }}>{title}</div>
        {subtitle && <div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 2 }}>{subtitle}</div>}
      </div>
      {badge && (
        <div style={{
          fontSize: 12,
          color: badgeColor || 'var(--accent)',
          background: badgeColor ? badgeColor.replace('var(--', 'rgba(').replace(')', ', 0.1)').replace('red', '248,113,113').replace('green', '52,211,153').replace('amber', '251,191,36').replace('accent', '79,142,247') : 'rgba(79,142,247,0.1)',
          padding: '4px 10px', borderRadius: 6,
          border: `1px solid ${badgeColor || 'var(--accent)'}44`
        }}>
          {badge}
        </div>
      )}
    </div>
  )
}

export default function DashboardPage() {
  const [data, setData] = useState(null)
  const [forecast, setForecast] = useState(null)
  const [arima, setArima] = useState(null)
  const [anomalies, setAnomalies] = useState(null)
  const [vendorRisk, setVendorRisk] = useState(null)
  const [duplicates, setDuplicates] = useState(null)
  const [rfData, setRfData] = useState(null)
  const [dbscanData, setDbscanData] = useState(null)
  const [categorizing, setCategorizing] = useState(false)
  const [categorizeResult, setCategorizeResult] = useState(null)
  const [loading, setLoading] = useState(true)
  const [exporting, setExporting] = useState(false)
  const { user } = useAuth()

  useEffect(() => {
    analyticsAPI.summary().then(r => setData(r.data)).finally(() => setLoading(false))
    forecastAPI.get(3).then(r => setForecast(r.data)).catch(() => {})
    arimaAPI.get(3).then(r => setArima(r.data)).catch(() => {})
    anomalyAPI.get().then(r => setAnomalies(r.data)).catch(() => {})
    vendorRiskAPI.get().then(r => setVendorRisk(r.data)).catch(() => {})
    duplicateAPI.get().then(r => setDuplicates(r.data)).catch(() => {})
    randomForestAPI.get().then(r => setRfData(r.data)).catch(() => {})
    dbscanAPI.get().then(r => setDbscanData(r.data)).catch(() => {})
  }, [])

  const handleExport = async () => {
    setExporting(true)
    try {
      const res = await reportsAPI.exportExcel()
      const url = window.URL.createObjectURL(new Blob([res.data]))
      const a = document.createElement('a')
      a.href = url; a.download = 'finance_report.xlsx'; a.click()
      window.URL.revokeObjectURL(url)
    } catch (e) { alert('Export failed') } finally { setExporting(false) }
  }

  const handleCategorize = async () => {
    setCategorizing(true)
    try {
      const res = await categorizeAPI.run()
      setCategorizeResult(res.data)
      analyticsAPI.summary().then(r => setData(r.data))
    } catch (e) { alert('Categorization failed') } finally { setCategorizing(false) }
  }

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '60vh' }}>
        <div className="spinner" style={{ width: 32, height: 32 }} />
      </div>
    )
  }

  const riskColor = (level) => level === 'HIGH' ? 'var(--red)' : level === 'MEDIUM' ? 'var(--amber)' : 'var(--green)'

  return (
    <div className="animate-in">

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
        <div>
          <h1 className="page-title">Good {new Date().getHours() < 12 ? 'morning' : 'afternoon'}, {user?.full_name?.split(' ')[0]}</h1>
          <p className="page-subtitle">Here is your finance overview</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn" onClick={handleCategorize} disabled={categorizing} style={{ fontSize: 13 }}>
            {categorizing ? 'Running NLP...' : 'Run NLP Categorizer'}
          </button>
          <button className="btn btn-primary" onClick={handleExport} disabled={exporting}>
            {exporting ? 'Exporting...' : 'Export Excel'}
          </button>
        </div>
      </div>

      {/* NLP Result */}
      {categorizeResult && (
        <div style={{ marginBottom: 20, padding: '12px 16px', background: 'rgba(52,211,153,0.08)', border: '1px solid rgba(52,211,153,0.25)', borderRadius: 10 }}>
          <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--green)', marginBottom: 6 }}>NLP Categorization Complete</div>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            {categorizeResult.results?.map((r, i) => (
              <div key={i} style={{ fontSize: 12, color: 'var(--text2)' }}>
                <span style={{ color: 'var(--text)' }}>{r.vendor || 'Unknown'}</span>
                {' '}{r.old_category} to <span style={{ color: 'var(--green)' }}>{r.new_category}</span> ({r.confidence}%)
              </div>
            ))}
          </div>
        </div>
      )}

      {/* KPI Cards */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 24, flexWrap: 'wrap' }}>
        <KpiCard label="Total Spend" value={'$' + (data?.total_spend || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })} sub={(data?.invoice_count || 0) + ' invoices total'} color="var(--accent)" />
        <KpiCard label="Approved" value={data?.approved_count || 0} sub="Processed and cleared" color="var(--green)" />
        <KpiCard label="Flagged" value={data?.flagged_count || 0} sub="Needs review" color="var(--red)" />
        <KpiCard label="Pending" value={data?.pending_count || 0} sub="Awaiting processing" color="var(--amber)" />
      </div>

      {/* Charts Row */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: 16, marginBottom: 24 }}>
        <div className="card">
          <div style={{ fontWeight: 500, marginBottom: 20, fontSize: 15 }}>Monthly spend</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={data?.monthly_data || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'var(--text3)' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: 'var(--text3)' }} axisLine={false} tickLine={false} tickFormatter={v => '$' + (v / 1000).toFixed(0) + 'k'} />
              <Tooltip contentStyle={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="total" fill="var(--accent)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <div style={{ fontWeight: 500, marginBottom: 20, fontSize: 15 }}>By category</div>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={data?.category_breakdown || []} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="total" nameKey="category" paddingAngle={3}>
                {(data?.category_breakdown || []).map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip formatter={v => '$' + v.toLocaleString()} contentStyle={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
            {(data?.category_breakdown || []).slice(0, 4).map((c, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 12 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ width: 8, height: 8, borderRadius: 2, background: COLORS[i % COLORS.length], flexShrink: 0 }} />
                  <span style={{ color: 'var(--text2)' }}>{c.category}</span>
                </div>
                <span style={{ color: 'var(--text)', fontFamily: 'var(--mono)', fontSize: 11 }}>${c.total.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ARIMA Forecast */}
      {arima && arima.forecasts && arima.forecasts.length > 0 && (
        <div className="card" style={{ marginBottom: 24 }}>
          <SectionHeader
            title="ARIMA Time Series Forecast"
            subtitle={'Model: ' + (arima.model || 'ARIMA') + (arima.aic_score ? ' - AIC: ' + arima.aic_score : '')}
            badge="Time Series AI"
            badgeColor="var(--purple)"
          />
          {arima.insight && (
            <div style={{ fontSize: 13, color: 'var(--text2)', background: 'var(--bg3)', padding: '10px 14px', borderRadius: 8, marginBottom: 16, borderLeft: '3px solid var(--purple)' }}>
              {arima.insight}
            </div>
          )}
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={[
              ...(arima.historical || []).map(h => ({ month: h.month, actual: h.total, predicted: null })),
              ...(arima.forecasts || []).map(f => ({ month: f.month, actual: null, predicted: f.predicted }))
            ]}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: 'var(--text3)' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: 'var(--text3)' }} axisLine={false} tickLine={false} tickFormatter={v => '$' + (v / 1000).toFixed(0) + 'k'} />
              <Tooltip contentStyle={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 8, fontSize: 12 }} formatter={v => v ? '$' + v.toLocaleString() : 'N/A'} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="actual" stroke="var(--accent)" strokeWidth={2} dot={{ fill: 'var(--accent)', r: 4 }} name="Actual" connectNulls={false} />
              <Line type="monotone" dataKey="predicted" stroke="var(--purple)" strokeWidth={2} strokeDasharray="5 5" dot={{ fill: 'var(--purple)', r: 4 }} name="ARIMA Forecast" connectNulls={false} />
            </LineChart>
          </ResponsiveContainer>
          <div style={{ display: 'flex', gap: 12, marginTop: 12 }}>
            {(arima.forecasts || []).map((f, i) => (
              <div key={i} style={{ flex: 1, background: 'var(--bg3)', borderRadius: 8, padding: '10px 14px', border: '1px solid var(--border)' }}>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 4 }}>{f.month}</div>
                <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--purple)' }}>${f.predicted.toLocaleString()}</div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 2 }}>${f.lower.toLocaleString()} - ${f.upper.toLocaleString()}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Random Forest Predictions */}
      {rfData && rfData.status === 'success' && (
        <div className="card" style={{ marginBottom: 24 }}>
          <SectionHeader
            title="Invoice Amount Prediction — Random Forest"
            subtitle={'Model: Random Forest Regressor (100 trees) - MAE: $' + rfData.model_performance?.mae?.toLocaleString()}
            badge={rfData.model_performance?.unusual_count > 0 ? rfData.model_performance.unusual_count + ' Unusual Found' : 'All Normal'}
            badgeColor={rfData.model_performance?.unusual_count > 0 ? 'var(--red)' : 'var(--green)'}
          />

          {rfData.model_performance?.top_features && (
            <div style={{ display: 'flex', gap: 10, marginBottom: 16 }}>
              {rfData.model_performance.top_features.map((f, i) => (
                <div key={i} style={{ flex: 1, background: 'var(--bg3)', borderRadius: 8, padding: '8px 12px', border: '1px solid var(--border)' }}>
                  <div style={{ fontSize: 11, color: 'var(--text3)' }}>Feature {i + 1}</div>
                  <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)', marginTop: 2 }}>{f.feature.replace('_enc', '').replace('_', ' ')}</div>
                  <div style={{ fontSize: 12, color: 'var(--accent)' }}>{f.importance}% importance</div>
                </div>
              ))}
            </div>
          )}

          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                <th style={{ textAlign: 'left', padding: '0 0 10px', fontSize: 12, color: 'var(--text3)', fontWeight: 500 }}>Vendor</th>
                <th style={{ textAlign: 'right', padding: '0 0 10px', fontSize: 12, color: 'var(--text3)', fontWeight: 500 }}>Actual</th>
                <th style={{ textAlign: 'right', padding: '0 0 10px', fontSize: 12, color: 'var(--text3)', fontWeight: 500 }}>Predicted</th>
                <th style={{ textAlign: 'right', padding: '0 0 10px', fontSize: 12, color: 'var(--text3)', fontWeight: 500 }}>Deviation</th>
                <th style={{ textAlign: 'center', padding: '0 0 10px', fontSize: 12, color: 'var(--text3)', fontWeight: 500 }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {(rfData.predictions || []).map((p, i) => (
                <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '10px 0', fontSize: 13, color: 'var(--text)' }}>{p.vendor}</td>
                  <td style={{ padding: '10px 0', textAlign: 'right', fontFamily: 'var(--mono)', fontSize: 12 }}>${p.actual_amount.toLocaleString()}</td>
                  <td style={{ padding: '10px 0', textAlign: 'right', fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--accent)' }}>${p.predicted_amount.toLocaleString()}</td>
                  <td style={{ padding: '10px 0', textAlign: 'right', fontFamily: 'var(--mono)', fontSize: 12, color: p.is_unusual ? 'var(--red)' : 'var(--text3)' }}>
                    {p.deviation_pct.toFixed(1)}%
                  </td>
                  <td style={{ padding: '10px 0', textAlign: 'center' }}>
                    <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 4, background: p.is_unusual ? 'rgba(248,113,113,0.1)' : 'rgba(52,211,153,0.1)', color: p.is_unusual ? 'var(--red)' : 'var(--green)', fontWeight: 500 }}>
                      {p.is_unusual ? 'Unusual' : 'Normal'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div style={{ marginTop: 12, padding: '8px 12px', background: 'var(--bg3)', borderRadius: 6, fontSize: 12, color: 'var(--text3)' }}>
            Features: Vendor encoding - Category - Month - Quarter - Tax amount - Status
          </div>
        </div>
      )}

      {/* DBSCAN Spending Patterns */}
      {dbscanData && dbscanData.status === 'success' && (
        <div className="card" style={{ marginBottom: 24 }}>
          <SectionHeader
            title="Spending Pattern Discovery — DBSCAN"
            subtitle={'Density-Based Clustering - ' + dbscanData.n_clusters + ' patterns found, ' + dbscanData.outlier_count + ' outliers'}
            badge={dbscanData.n_clusters + ' Clusters Found'}
            badgeColor="var(--accent)"
          />

          {dbscanData.insights?.length > 0 && (
            <div style={{ marginBottom: 16 }}>
              {dbscanData.insights.map((insight, i) => (
                <div key={i} style={{ fontSize: 13, color: 'var(--text2)', background: 'var(--bg3)', padding: '8px 14px', borderRadius: 8, marginBottom: 8, borderLeft: '3px solid var(--accent)' }}>
                  {insight}
                </div>
              ))}
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12, marginBottom: 16 }}>
            {(dbscanData.clusters || []).map((cluster, i) => (
              <div key={i} style={{ background: 'var(--bg3)', borderRadius: 8, padding: '12px 16px', border: `1px solid ${COLORS[i % COLORS.length]}44` }}>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 6 }}>CLUSTER {cluster.cluster_id + 1}</div>
                <div style={{ fontSize: 15, fontWeight: 600, color: COLORS[i % COLORS.length] }}>{cluster.size} invoices</div>
                <div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 4 }}>Avg: ${cluster.avg_amount.toLocaleString()}</div>
                <div style={{ fontSize: 12, color: 'var(--text2)' }}>Total: ${cluster.total_spend.toLocaleString()}</div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>{cluster.dominant_category}</div>
              </div>
            ))}

            {dbscanData.outlier_count > 0 && (
              <div style={{ background: 'rgba(248,113,113,0.06)', borderRadius: 8, padding: '12px 16px', border: '1px solid rgba(248,113,113,0.2)' }}>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 6 }}>OUTLIERS</div>
                <div style={{ fontSize: 15, fontWeight: 600, color: 'var(--red)' }}>{dbscanData.outlier_count} invoices</div>
                <div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 4 }}>No matching pattern</div>
                <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>Review recommended</div>
              </div>
            )}
          </div>

          {dbscanData.outliers?.length > 0 && (
            <div>
              <div style={{ fontSize: 12, color: 'var(--text3)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Outlier Transactions</div>
              {dbscanData.outliers.map((o, i) => (
                <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 12px', background: 'rgba(248,113,113,0.06)', border: '1px solid rgba(248,113,113,0.15)', borderRadius: 6, marginBottom: 6 }}>
                  <span style={{ fontSize: 13, color: 'var(--text)' }}>{o.vendor}</span>
                  <span style={{ fontSize: 13, fontFamily: 'var(--mono)', color: 'var(--red)' }}>${o.amount.toLocaleString()}</span>
                </div>
              ))}
            </div>
          )}

          <div style={{ marginTop: 12, padding: '8px 12px', background: 'var(--bg3)', borderRadius: 6, fontSize: 12, color: 'var(--text3)' }}>
            Parameters: eps=0.8, min_samples=2 - Features: Amount, Tax ratio, Month
          </div>
        </div>
      )}

      {/* Anomaly Detection */}
      {anomalies && anomalies.status === 'success' && (
        <div className="card" style={{ marginBottom: 24 }}>
          <SectionHeader
            title="Anomaly Detection — Isolation Forest"
            subtitle={'Unsupervised ML - ' + anomalies.stats?.total_invoices + ' invoices analyzed'}
            badge={anomalies.stats?.anomalies_found > 0 ? anomalies.stats.anomalies_found + ' Anomalies' : 'All Normal'}
            badgeColor={anomalies.stats?.anomalies_found > 0 ? 'var(--red)' : 'var(--green)'}
          />
          {anomalies.anomalies?.length > 0 && (
            <div style={{ marginBottom: 12 }}>
              {anomalies.anomalies.map((a, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', background: 'rgba(248,113,113,0.06)', border: '1px solid rgba(248,113,113,0.2)', borderRadius: 8, marginBottom: 8 }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)' }}>{a.vendor}</div>
                    <div style={{ fontSize: 12, color: 'var(--text3)', marginTop: 2 }}>{a.reason}</div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 13, fontFamily: 'var(--mono)', color: 'var(--red)' }}>${a.amount.toLocaleString()}</div>
                    <div style={{ fontSize: 11, color: 'var(--text3)' }}>Risk: {a.risk_score.toFixed(0)}%</div>
                  </div>
                </div>
              ))}
            </div>
          )}
          {anomalies.normal?.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {anomalies.normal.map((n, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 12px', background: 'rgba(52,211,153,0.06)', border: '1px solid rgba(52,211,153,0.2)', borderRadius: 6 }}>
                  <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--green)' }} />
                  <span style={{ fontSize: 12, color: 'var(--text2)' }}>{n.vendor}</span>
                  <span style={{ fontSize: 12, fontFamily: 'var(--mono)', color: 'var(--text3)' }}>${n.amount.toLocaleString()}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Vendor Risk */}
      {vendorRisk && vendorRisk.status === 'success' && (
        <div className="card" style={{ marginBottom: 24 }}>
          <SectionHeader
            title="Vendor Risk Scoring — K-Means Clustering"
            subtitle={vendorRisk.vendors?.length + ' vendors profiled'}
            badge={vendorRisk.summary?.high_risk > 0 ? vendorRisk.summary.high_risk + ' High Risk' : 'All Low Risk'}
            badgeColor={vendorRisk.summary?.high_risk > 0 ? 'var(--red)' : 'var(--green)'}
          />
          <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
            {[
              { label: 'High Risk', value: vendorRisk.summary?.high_risk || 0, color: 'var(--red)', bg: 'rgba(248,113,113,0.08)', border: 'rgba(248,113,113,0.2)' },
              { label: 'Medium Risk', value: vendorRisk.summary?.medium_risk || 0, color: 'var(--amber)', bg: 'rgba(251,191,36,0.08)', border: 'rgba(251,191,36,0.2)' },
              { label: 'Low Risk', value: vendorRisk.summary?.low_risk || 0, color: 'var(--green)', bg: 'rgba(52,211,153,0.08)', border: 'rgba(52,211,153,0.2)' },
            ].map((item, i) => (
              <div key={i} style={{ flex: 1, textAlign: 'center', padding: '10px', background: item.bg, borderRadius: 8, border: `1px solid ${item.border}` }}>
                <div style={{ fontSize: 22, fontWeight: 600, color: item.color }}>{item.value}</div>
                <div style={{ fontSize: 11, color: 'var(--text3)' }}>{item.label}</div>
              </div>
            ))}
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)' }}>
                {['Vendor', 'Risk Level', 'Risk Score', 'Total Spend'].map(h => (
                  <th key={h} style={{ textAlign: h === 'Vendor' ? 'left' : 'right', padding: '0 0 10px', fontSize: 12, color: 'var(--text3)', fontWeight: 500 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(vendorRisk.vendors || []).map((v, i) => (
                <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '10px 0', fontSize: 13 }}>{v.vendor}</td>
                  <td style={{ padding: '10px 0', textAlign: 'right' }}>
                    <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 4, background: v.risk_level === 'HIGH' ? 'rgba(248,113,113,0.1)' : v.risk_level === 'MEDIUM' ? 'rgba(251,191,36,0.1)' : 'rgba(52,211,153,0.1)', color: riskColor(v.risk_level), fontWeight: 500 }}>
                      {v.risk_level}
                    </span>
                  </td>
                  <td style={{ padding: '10px 0', textAlign: 'right', fontFamily: 'var(--mono)', fontSize: 12, color: riskColor(v.risk_level) }}>{v.risk_score.toFixed(0)}%</td>
                  <td style={{ padding: '10px 0', textAlign: 'right', fontFamily: 'var(--mono)', fontSize: 12 }}>${v.total_spend.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Duplicate Detection */}
      {duplicates && duplicates.status === 'success' && (
        <div className="card" style={{ marginBottom: 24 }}>
          <SectionHeader
            title="Duplicate Detection — TF-IDF Cosine Similarity"
            subtitle={duplicates.total_invoices + ' invoices scanned'}
            badge={duplicates.duplicates_found > 0 ? duplicates.duplicates_found + ' Duplicates' : 'No Duplicates'}
            badgeColor={duplicates.duplicates_found > 0 ? 'var(--red)' : 'var(--green)'}
          />
          {duplicates.duplicate_pairs?.length > 0 ? (
            duplicates.duplicate_pairs.map((pair, i) => (
              <div key={i} style={{ padding: '12px 14px', background: 'rgba(248,113,113,0.06)', border: '1px solid rgba(248,113,113,0.2)', borderRadius: 8, marginBottom: 10 }}>
                <div style={{ fontSize: 12, color: 'var(--red)', marginBottom: 8 }}>Similarity: {pair.similarity_score}% - Risk: {pair.risk}</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  {[pair.invoice_1, pair.invoice_2].map((inv, j) => (
                    <div key={j} style={{ padding: '8px 12px', background: 'var(--bg3)', borderRadius: 6 }}>
                      <div style={{ fontSize: 13, fontWeight: 500 }}>{inv.vendor}</div>
                      <div style={{ fontSize: 12, color: 'var(--text3)' }}>{inv.invoice_number}</div>
                      <div style={{ fontSize: 13, fontFamily: 'var(--mono)' }}>${inv.amount.toLocaleString()}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))
          ) : (
            <div style={{ padding: '20px', textAlign: 'center', color: 'var(--green)', fontSize: 14 }}>
              All invoices are unique. No duplicates detected.
            </div>
          )}
        </div>
      )}

      {/* Top Vendors */}
      <div className="card">
        <div style={{ fontWeight: 500, marginBottom: 16, fontSize: 15 }}>Top vendors</div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border)' }}>
              <th style={{ textAlign: 'left', padding: '0 0 10px', fontSize: 12, color: 'var(--text3)', fontWeight: 500 }}>Vendor</th>
              <th style={{ textAlign: 'right', padding: '0 0 10px', fontSize: 12, color: 'var(--text3)', fontWeight: 500 }}>Total Spend</th>
            </tr>
          </thead>
          <tbody>
            {(data?.top_vendors || []).map((v, i) => (
              <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                <td style={{ padding: '12px 0', fontSize: 14 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 28, height: 28, borderRadius: 6, background: COLORS[i % COLORS.length] + '22', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, color: COLORS[i % COLORS.length], fontWeight: 600 }}>
                      {v.name?.[0]?.toUpperCase()}
                    </div>
                    {v.name}
                  </div>
                </td>
                <td style={{ padding: '12px 0', textAlign: 'right', fontFamily: 'var(--mono)', fontSize: 13 }}>${v.total.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
              </tr>
            ))}
            {!data?.top_vendors?.length && (
              <tr><td colSpan={2} style={{ padding: '20px 0', textAlign: 'center', color: 'var(--text3)', fontSize: 13 }}>No invoice data yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>

    </div>
  )
}
