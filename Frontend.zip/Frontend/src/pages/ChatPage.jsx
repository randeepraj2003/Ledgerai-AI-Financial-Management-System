import { useEffect, useState, useRef } from 'react'
import { chatAPI } from '../services/api'

const RAG_API = 'http://localhost:8001'

const SUGGESTIONS = [
  'What is my total spend this month?',
  'Show me all flagged invoices',
  'Who are my top vendors by spend?',
  'How many invoices are pending approval?',
  'Summarize my spending for this year',
]

function Message({ role, content, sources }) {
  const isUser = role === 'user'
  return (
    <div style={{ display: 'flex', justifyContent: isUser ? 'flex-end' : 'flex-start', marginBottom: 16 }}>
      {!isUser && (
        <div style={{
          width: 32, height: 32, borderRadius: 8, background: 'var(--accent)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 14, flexShrink: 0, marginRight: 10, marginTop: 2
        }}>⚡</div>
      )}
      <div style={{ maxWidth: '72%' }}>
        <div style={{
          padding: '12px 16px',
          borderRadius: isUser ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
          background: isUser ? 'var(--accent)' : 'var(--bg2)',
          border: isUser ? 'none' : '1px solid var(--border)',
          fontSize: 14, lineHeight: 1.6,
          color: isUser ? '#fff' : 'var(--text)',
          whiteSpace: 'pre-wrap', wordBreak: 'break-word'
        }}>
          {content}
        </div>

        {/* RAG Source Citations */}
        {sources?.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 6 }}>
            {sources.map((s, i) => (
              <span key={i} style={{
                fontSize: 11, padding: '2px 8px',
                background: 'rgba(99,102,241,0.15)',
                border: '1px solid rgba(99,102,241,0.3)',
                borderRadius: 20, color: '#818cf8'
              }}>
                📄 {s.filename} ({Math.round(s.score * 100)}%)
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

// PDF Upload Zone for RAG indexing
function UploadZone({ onUpload, indexedCount }) {
  const [dragging, setDragging] = useState(false)
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef()

  const handleFiles = async (files) => {
    setUploading(true)
    for (const file of files) {
      if (!file.name.endsWith('.pdf')) continue
      const form = new FormData()
      form.append('file', file)
      try {
        const res  = await fetch(`${RAG_API}/api/rag/upload`, { method: 'POST', body: form })
        const data = await res.json()
        onUpload(data)
      } catch {
        console.error('Upload failed for', file.name)
      }
    }
    setUploading(false)
  }

  return (
    <div
      onDragOver={e => { e.preventDefault(); setDragging(true) }}
      onDragLeave={() => setDragging(false)}
      onDrop={e => { e.preventDefault(); setDragging(false); handleFiles([...e.dataTransfer.files]) }}
      onClick={() => fileRef.current?.click()}
      style={{
        border: `2px dashed ${dragging ? 'var(--accent)' : 'var(--border)'}`,
        borderRadius: 10, padding: '12px 18px', marginBottom: 16,
        background: dragging ? 'rgba(99,102,241,0.06)' : 'var(--bg2)',
        cursor: 'pointer', transition: 'all 0.2s',
        display: 'flex', alignItems: 'center', gap: 12,
      }}
    >
      <span style={{ fontSize: 20 }}>📎</span>
      <div>
        <div style={{ fontSize: 13, color: 'var(--text2)' }}>
          {uploading
            ? '⏳ Indexing PDF for RAG...'
            : 'Drop PDF invoices here to enable smart search'}
        </div>
        {indexedCount > 0 && (
          <div style={{ fontSize: 11, color: '#818cf8', marginTop: 2 }}>
            ✓ {indexedCount} file(s) indexed — RAG is active
          </div>
        )}
      </div>
      <input
        ref={fileRef} type="file" accept=".pdf"
        multiple hidden
        onChange={e => handleFiles([...e.target.files])}
      />
    </div>
  )
}

export default function ChatPage() {
  const [messages,     setMessages]     = useState([])
  const [input,        setInput]        = useState('')
  const [loading,      setLoading]      = useState(false)
  const [historyLoaded,setHistoryLoaded]= useState(false)
  const [indexedCount, setIndexedCount] = useState(0)
  const [ragActive,    setRagActive]    = useState(false)
  const bottomRef = useRef(null)

  // Load chat history
  useEffect(() => {
    chatAPI.history()
      .then(res => { setMessages(res.data); setHistoryLoaded(true) })
      .catch(() => setHistoryLoaded(true))
  }, [])

  // Check if RAG server is live
  useEffect(() => {
    fetch(`${RAG_API}/api/rag/status`)
      .then(r => r.json())
      .then(d => {
        setRagActive(true)
        setIndexedCount(d.indexed_files?.length || 0)
      })
      .catch(() => setRagActive(false))
  }, [])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleUpload = (data) => {
    setIndexedCount(prev => prev + 1)
    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `✅ Indexed "${data.invoice_id}" — ${data.chunks} chunks stored in vector DB.\nYou can now ask questions about this invoice!`,
      sources: []
    }])
  }

  const send = async (text) => {
    const msg = text || input.trim()
    if (!msg || loading) return
    setInput('')
    setMessages(prev => [...prev, { role: 'user', content: msg }])
    setLoading(true)

    try {
      // Try RAG first if server is active
      if (ragActive) {
        const ragRes = await fetch(`${RAG_API}/api/rag/query`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ question: msg })
        })
        if (ragRes.ok) {
          const ragData = await ragRes.json()
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: ragData.answer,
            sources: ragData.sources || []
          }])
          setLoading(false)
          return
        }
      }

      // Fallback to existing chat API
      const res = await chatAPI.send(msg)
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: res.data.response
      }])

    } catch {
      // Last resort fallback
      try {
        const res = await chatAPI.send(msg)
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: res.data.response
        }])
      } catch {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: 'Sorry, I ran into an error. Please try again.'
        }])
      }
    } finally {
      setLoading(false)
    }
  }

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() }
  }

  return (
    <div className="animate-in" style={{ height: 'calc(100vh - 56px)', display: 'flex', flexDirection: 'column' }}>

      {/* Header */}
      <div style={{ marginBottom: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <h1 className="page-title">AI Finance Assistant</h1>
            <p className="page-subtitle">Ask anything about your invoices, spending, or vendors</p>
          </div>
          {/* RAG Status Badge */}
          <div style={{
            padding: '5px 12px', borderRadius: 20, fontSize: 12, fontWeight: 500,
            background: ragActive ? 'rgba(34,197,94,0.1)' : 'rgba(255,255,255,0.05)',
            border: `1px solid ${ragActive ? 'rgba(34,197,94,0.3)' : 'var(--border)'}`,
            color: ragActive ? '#4ade80' : 'var(--text3)',
          }}>
            {ragActive ? '🟢 RAG Active' : '⚪ RAG Offline'}
          </div>
        </div>
      </div>

      {/* Chat Card */}
      <div className="card" style={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column', padding: 0 }}>

        {/* PDF Upload Zone */}
        {ragActive && (
          <div style={{ padding: '16px 20px 0' }}>
            <UploadZone onUpload={handleUpload} indexedCount={indexedCount} />
          </div>
        )}

        {/* Messages */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '20px 24px' }}>

          {!historyLoaded && (
            <div style={{ textAlign: 'center', padding: 20 }}>
              <div className="spinner" style={{ margin: '0 auto' }} />
            </div>
          )}

          {historyLoaded && messages.length === 0 && (
            <div style={{ textAlign: 'center', padding: '32px 20px' }}>
              <div style={{ fontSize: 36, marginBottom: 12 }}>⚡</div>
              <div style={{ fontWeight: 500, fontSize: 16, marginBottom: 6 }}>LedgerAI Assistant</div>
              <div style={{ color: 'var(--text2)', fontSize: 14, marginBottom: 8 }}>
                I can analyze your invoices, spending patterns, and flag anomalies.
              </div>
              {ragActive && indexedCount > 0 && (
                <div style={{ color: '#818cf8', fontSize: 13, marginBottom: 20 }}>
                  🔍 RAG enabled — I can search through your {indexedCount} indexed PDF(s)
                </div>
              )}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, maxWidth: 400, margin: '0 auto' }}>
                {SUGGESTIONS.map((s, i) => (
                  <button key={i} onClick={() => send(s)} className="btn"
                    style={{ justifyContent: 'flex-start', fontSize: 13, padding: '10px 16px', textAlign: 'left' }}>
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <Message key={i} role={msg.role} content={msg.content} sources={msg.sources} />
          ))}

          {loading && (
            <div style={{ display: 'flex', alignItems: 'flex-start', marginBottom: 16 }}>
              <div style={{
                width: 32, height: 32, borderRadius: 8, background: 'var(--accent)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 14, flexShrink: 0, marginRight: 10
              }}>⚡</div>
              <div style={{
                padding: '12px 16px', borderRadius: '16px 16px 16px 4px',
                background: 'var(--bg2)', border: '1px solid var(--border)',
                display: 'flex', gap: 5, alignItems: 'center'
              }}>
                {[0, 1, 2].map(i => (
                  <div key={i} style={{
                    width: 6, height: 6, borderRadius: '50%',
                    background: 'var(--text3)',
                    animation: 'bounce 1.2s infinite',
                    animationDelay: `${i * 0.2}s`
                  }} />
                ))}
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div style={{ borderTop: '1px solid var(--border)', padding: '16px 20px', display: 'flex', gap: 10 }}>
          <textarea
            className="input"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Ask about your finances… (Enter to send)"
            rows={2}
            style={{ flex: 1, resize: 'none', lineHeight: 1.5, paddingTop: 10 }}
          />
          <button
            className="btn btn-primary"
            onClick={() => send()}
            disabled={loading || !input.trim()}
            style={{ alignSelf: 'flex-end', padding: '10px 16px', minWidth: 80 }}
          >
            {loading
              ? <div className="spinner" style={{ width: 16, height: 16, borderColor: 'rgba(255,255,255,0.3)', borderTopColor: '#fff' }} />
              : 'Send'}
          </button>
        </div>
      </div>

      <style>{`
        @keyframes bounce {
          0%,80%,100% { transform: translateY(0) }
          40%          { transform: translateY(-6px) }
        }
      `}</style>
    </div>
  )
}
