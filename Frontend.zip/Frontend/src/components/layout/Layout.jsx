import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../../hooks/useAuth'

const NavItem = ({ to, icon, label }) => (
  <NavLink to={to} end={to === '/'} style={({ isActive }) => ({
    display: 'flex', alignItems: 'center', gap: '10px',
    padding: '9px 12px', borderRadius: '8px',
    color: isActive ? 'var(--text)' : 'var(--text2)',
    background: isActive ? 'var(--bg3)' : 'transparent',
    fontSize: '14px', fontWeight: isActive ? '500' : '400',
    transition: 'all 0.15s', textDecoration: 'none',
  })}>
    <span style={{ fontSize: '16px' }}>{icon}</span>
    {label}
  </NavLink>
)

export default function Layout() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const handleLogout = () => { logout(); navigate('/login') }
  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <aside style={{ width: '220px', flexShrink: 0, background: 'var(--bg2)', borderRight: '1px solid var(--border)', display: 'flex', flexDirection: 'column', padding: '20px 12px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '0 8px', marginBottom: '28px' }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>⚡</div>
          <span style={{ fontWeight: 600, fontSize: 15, color: 'var(--text)' }}>LedgerAI</span>
        </div>
        <nav style={{ display: 'flex', flexDirection: 'column', gap: '2px', flex: 1 }}>
          <NavItem to="/" icon="▦" label="Dashboard" />
<NavItem to="/invoices" icon="📂" label="Invoices" />
<NavItem to="/chat" icon="💬" label="AI Assistant" />        </nav>
        <div style={{ borderTop: '1px solid var(--border)', paddingTop: '16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '8px', borderRadius: '8px' }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 600, color: '#fff', flexShrink: 0 }}>
              {user?.full_name?.[0]?.toUpperCase() || 'U'}
            </div>
            <div style={{ overflow: 'hidden', flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user?.full_name}</div>
              <div style={{ fontSize: 11, color: 'var(--text3)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user?.email}</div>
            </div>
          </div>
          <button onClick={handleLogout} className="btn" style={{ width: '100%', marginTop: '8px', justifyContent: 'center', fontSize: 13 }}>Sign out</button>
        </div>
      </aside>
      <main style={{ flex: 1, overflow: 'auto', padding: '28px 32px', background: 'var(--bg)' }}>
        <Outlet />
      </main>
    </div>
  )
}
